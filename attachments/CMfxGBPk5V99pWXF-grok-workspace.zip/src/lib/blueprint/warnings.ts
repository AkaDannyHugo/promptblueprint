import { TIMEFRAME_MINUTES } from "./constants";
import { weightTotal } from "./format";
import type { BlueprintConfig, Notice } from "./types";

export function getNotices(config: BlueprintConfig): Notice[] {
  const notices: Notice[] = [];
  const total = weightTotal(config);
  const entryMin = TIMEFRAME_MINUTES[config.entryTf];
  const overlap = (config.watchlist ?? []).filter((t) =>
    (config.denylist ?? []).includes(t),
  );

  if (total !== 100) {
    notices.push({
      level: "warn",
      message: `Weights sum to ${total}, not 100. The contract will normalize them.`,
    });
  }

  if (config.universeMode === "category" && config.category === "any") {
    notices.push({
      level: "warn",
      message: "Category mode needs a sector, or the contract stops.",
    });
  }

  if (config.category === "Stablecoin" && config.excludeStables) {
    notices.push({
      level: "warn",
      message: "Stablecoin category with stablecoins excluded returns nothing.",
    });
  }

  if (TIMEFRAME_MINUTES[config.trendTf] < entryMin) {
    notices.push({
      level: "warn",
      message: "Trend timeframe is shorter than entry. Raise it.",
    });
  }

  if (overlap.length) {
    notices.push({
      level: "warn",
      message: `${overlap.join(", ")} is on both lists. Denylist wins.`,
    });
  }

  if (config.trendTf === "1W") {
    notices.push({
      level: "info",
      message: "Weekly trend is five daily closes. There is no weekly candle.",
    });
  }

  if (
    (config.taVsOnchain && config.taVsOnchainPenalty < 0.8) ||
    (config.taVsSentiment && config.taVsSentimentPenalty < 0.8)
  ) {
    notices.push({
      level: "warn",
      message: "A penalty under 0.80 crushes scores. The floor still applies.",
    });
  }

  const leverage = config.marketMode === "leverage";
  if (leverage && config.signalBias === "short" && !config.compareInstruments) {
    notices.push({
      level: "info",
      message: "Shorts need a listed contract. Unmapped names drop.",
    });
  }
  if (leverage && config.leverageVenue === "global_perps") {
    notices.push({
      level: "info",
      message: "Global perps are non-US. INTX ids are retired.",
    });
  }
  if (leverage && config.maxLeverage > 5) {
    notices.push({
      level: "warn",
      message: "Above 5x is a leverage cap, not an edge. Liquidation buffer still cuts it.",
    });
  }
  if (leverage && config.marginMode === "cross") {
    notices.push({
      level: "warn",
      message: "Cross margin lets one idea drain the book.",
    });
  }
  if (
    leverage &&
    config.holdStyle === "intraday" &&
    (config.trendTf === "1D" || config.trendTf === "1W")
  ) {
    notices.push({
      level: "warn",
      message: "Intraday hold with a daily trend is a mismatch.",
    });
  }
  if (!leverage && config.compareInstruments) {
    notices.push({
      level: "info",
      message: "Compare will look for a listed contract and still keep spot shorts as research.",
    });
  }
  if (config.category === "Stablecoin" && leverage) {
    notices.push({
      level: "warn",
      message: "Stable leverage contracts are usually missing. Expect an empty list.",
    });
  }
  if (
    config.holdStyle === "intraday" &&
    config.entryTf === "15m" &&
    config.minRrr >= 2 &&
    config.slValidationMaxAtr != null
  ) {
    notices.push({
      level: "info",
      message:
        "A 6-bar stop on a 15m book near-misses PROFILE_SIDE. The contract will not flip side to print 2R.",
    });
  }
  if (config.weights.regime < 16) {
    notices.push({
      level: "info",
      message: "Regime points are fractions of this weight, not a 16–20 scale.",
    });
  }
  if (!leverage && config.weights.onchain > 0) {
    notices.push({
      level: "info",
      message: "On-chain stays na unless DefiLlama returns a number.",
    });
  }
  if (!leverage && config.signalBias === "short") {
    notices.push({
      level: "info",
      message: "Spot short stays RESEARCH_ONLY.",
    });
  }

  return notices;
}
