import type {
  BlueprintConfig,
  PillarId,
  ProfileId,
  TargetLlm,
  Timeframe,
  UniverseMode,
} from "./types.ts";

export const APP_NAME = "Prompt Blueprint";
export const APP_VERSION = "4.2";
export const PASS_C_MAX = 8;

export const PILLARS: {
  id: PillarId;
  label: string;
  short: string;
  max: number;
}[] = [
  { id: "regime", label: "Regime alignment", short: "Regime", max: 30 },
  { id: "technical", label: "Technical confluence", short: "Technical", max: 40 },
  { id: "derivatives", label: "Derivatives", short: "Derivs", max: 25 },
  { id: "onchain", label: "On-chain", short: "On-chain", max: 25 },
  { id: "sentiment", label: "Sentiment", short: "Sentiment", max: 20 },
  { id: "rr", label: "R/R magnitude", short: "R/R", max: 25 },
];

export const LLM_OPTIONS: { id: TargetLlm; label: string; hint: string }[] = [
  { id: "generic", label: "Any model", hint: "Discover tools, then call them." },
  { id: "grok", label: "Grok", hint: "Role first. Coinbase tools by exact name. Schema last." },
  { id: "claude", label: "Claude", hint: "Uses web search." },
  { id: "chatgpt", label: "ChatGPT", hint: "Uses browsing." },
  { id: "gemini", label: "Gemini", hint: "Uses Google Search." },
];

export const UNIVERSE_MODES: { id: UniverseMode; label: string; hint: string }[] = [
  { id: "marketcap", label: "Top N by market cap", hint: "Highest-value assets, broadest scope." },
  { id: "volume", label: "Top N by 24h spot volume", hint: "Most actively traded coins." },
  { id: "perp_oi", label: "Top N by perp OI / volume", hint: "Pass A still ranks Coinbase spot by volume. Open interest is read later, for the short list only." },
  { id: "category", label: "Top N inside category", hint: "Restrict to a chosen sector." },
];

export const CATEGORIES = [
  "any",
  "Layer 1",
  "Layer 2",
  "DeFi",
  "LSDfi",
  "RWA",
  "DePIN",
  "Gaming",
  "AI & Big Data",
  "Meme",
  "Privacy",
  "Infrastructure",
  "Exchange Tokens",
  "Stablecoin",
] as const;

export const ECOSYSTEMS = [
  "Ethereum",
  "Solana",
  "Base",
  "BSC",
  "Avalanche",
  "Polygon",
  "Arbitrum",
] as const;

export const TIMEFRAMES: Timeframe[] = ["15m", "1H", "4H", "1D", "1W"];

export const TIMEFRAME_MINUTES: Record<Timeframe, number> = {
  "15m": 15,
  "1H": 60,
  "4H": 240,
  "1D": 1440,
  "1W": 10080,
};

export const PROFILE_META: Record<
  ProfileId,
  { label: string; blurb: string }
> = {
  dayTrade: {
    label: "Day trade",
    blurb: "15m entries, 1H trend. Same-day momentum. Thin books are tagged, not deleted.",
  },
  momentum: {
    label: "Momentum",
    blurb: "1H entries, 4H trend. Time stop off. A swept low can be a reclaim long.",
  },
  meanReversion: {
    label: "Mean reversion",
    blurb: "Fade 1H overextensions back into daily structure.",
  },
  balanced: {
    label: "Balanced",
    blurb: "4H entries, 1D trend. Swing screen.",
  },
  conservative: {
    label: "Conservative",
    blurb: "Daily entries, weekly trend. Fewer, higher-conviction names.",
  },
};

type ProfilePatch = Partial<
  Pick<
    BlueprintConfig,
    | "minAtr"
    | "minRrr"
    | "entryTf"
    | "trendTf"
    | "minVolume"
    | "minMarketCap"
    | "confidence"
    | "numOps"
    | "staleness"
    | "coinbaseStaleness"
    | "atrDepthFallback"
    | "excludeNew"
    | "macroTf"
    | "taVsOnchain"
    | "taVsOnchainPenalty"
    | "taVsSentiment"
    | "taVsSentimentPenalty"
    | "sentimentMinN"
    | "sentimentFullN"
    | "minRvol"
    | "thinBookUsd"
    | "maxLeverage"
    | "liqBufferMultiple"
    | "fundingDragR"
    | "holdStyle"
    | "slValidationMaxAtr"
  >
> & { weights: BlueprintConfig["weights"] };

const SWING_FLAGS = {
  excludeNew: true,
  macroTf: "7 days" as const,
  taVsOnchain: true,
  taVsOnchainPenalty: 0.85,
  taVsSentiment: true,
  taVsSentimentPenalty: 0.9,
  sentimentMinN: 8,
  sentimentFullN: 8,
  minRvol: 2,
  thinBookUsd: 50_000,
};

/** Active desks. The written 5/40/20/0/5/15 set sums to 85. Technical is already at its cap, so the leftover 15 sits on derivatives and R/R. */
const DESK_WEIGHTS: BlueprintConfig["weights"] = {
  regime: 5,
  technical: 40,
  derivatives: 25,
  onchain: 0,
  sentiment: 5,
  rr: 25,
};

export const PROFILE_PATCHES: Record<ProfileId, ProfilePatch> = {
  dayTrade: {
    weights: { ...DESK_WEIGHTS },
    minAtr: 0.4,
    minRrr: 1.5,
    entryTf: "15m",
    trendTf: "1H",
    minVolume: 5_000_000,
    minMarketCap: 10_000_000,
    confidence: 60,
    numOps: 8,
    staleness: 45,
    coinbaseStaleness: 15,
    atrDepthFallback: 50_000,
    excludeNew: false,
    macroTf: "24 hours",
    taVsOnchain: false,
    taVsOnchainPenalty: 0.85,
    taVsSentiment: true,
    taVsSentimentPenalty: 0.95,
    sentimentMinN: 2,
    sentimentFullN: 2,
    minRvol: 2,
    thinBookUsd: 50_000,
    maxLeverage: 3,
    liqBufferMultiple: 2,
    fundingDragR: 0.25,
    holdStyle: "intraday",
    slValidationMaxAtr: 1.5,
  },
  momentum: {
    weights: { ...DESK_WEIGHTS },
    minAtr: 0.4,
    minRrr: 1.5,
    entryTf: "1H",
    trendTf: "4H",
    minVolume: 1_000_000,
    minMarketCap: 5_000_000,
    confidence: 55,
    numOps: 5,
    staleness: 90,
    coinbaseStaleness: 30,
    atrDepthFallback: 75_000,
    ...SWING_FLAGS,
    taVsOnchain: false,
    sentimentMinN: 2,
    sentimentFullN: 2,
    maxLeverage: 3,
    liqBufferMultiple: 2,
    fundingDragR: 0.25,
    holdStyle: "intraday",
    slValidationMaxAtr: 1.5,
  },
  meanReversion: {
    weights: {
      regime: 15,
      technical: 25,
      derivatives: 10,
      onchain: 20,
      sentiment: 10,
      rr: 20,
    },
    minAtr: 1.5,
    minRrr: 1.5,
    entryTf: "1H",
    trendTf: "1D",
    minVolume: 10_000_000,
    minMarketCap: 50_000_000,
    confidence: 70,
    numOps: 5,
    staleness: 90,
    coinbaseStaleness: 30,
    atrDepthFallback: 75_000,
    ...SWING_FLAGS,
    maxLeverage: 2,
    liqBufferMultiple: 2,
    fundingDragR: 0.2,
    holdStyle: "swing",
  },
  balanced: {
    weights: {
      regime: 20,
      technical: 25,
      derivatives: 15,
      onchain: 10,
      sentiment: 15,
      rr: 15,
    },
    minAtr: 3.0,
    minRrr: 1.5,
    entryTf: "4H",
    trendTf: "1D",
    minVolume: 5_000_000,
    minMarketCap: 50_000_000,
    confidence: 70,
    numOps: 5,
    staleness: 90,
    coinbaseStaleness: 30,
    atrDepthFallback: 75_000,
    ...SWING_FLAGS,
    maxLeverage: 2,
    liqBufferMultiple: 2,
    fundingDragR: 0.2,
    holdStyle: "swing",
  },
  conservative: {
    weights: {
      regime: 25,
      technical: 20,
      derivatives: 15,
      onchain: 15,
      sentiment: 5,
      rr: 20,
    },
    minAtr: 2.0,
    minRrr: 2.0,
    entryTf: "1D",
    trendTf: "1W",
    minVolume: 50_000_000,
    minMarketCap: 250_000_000,
    confidence: 80,
    numOps: 3,
    staleness: 90,
    coinbaseStaleness: 30,
    atrDepthFallback: 75_000,
    ...SWING_FLAGS,
    maxLeverage: 2,
    liqBufferMultiple: 2.5,
    fundingDragR: 0.15,
    holdStyle: "swing",
  },
};

export const DEFAULT_CONFIG: BlueprintConfig = {
  universeMode: "volume",
  universeSize: 50,
  category: "any",
  ecosystems: [],
  excludeStables: true,
  excludeWrapped: true,
  excludeNew: false,
  minVolume: 5_000_000,
  minMarketCap: 10_000_000,
  minAtr: 0.4,
  confidence: 60,
  numOps: 8,
  macroTf: "24 hours",
  entryTf: "15m",
  trendTf: "1H",
  minRrr: 1.5,
  staleness: 45,
  coinbaseStaleness: 15,
  atrDepthFallback: 50_000,
  weights: { ...PROFILE_PATCHES.dayTrade.weights },
  includeRefs: true,
  includeAudit: true,
  includeMetadata: false,
  taVsOnchain: false,
  taVsOnchainPenalty: 0.85,
  taVsSentiment: true,
  taVsSentimentPenalty: 0.95,
  slValidationMaxAtr: 1.5,
  targetLlm: "grok",
  profile: "dayTrade",
  customVars: [],
  darkMode: true,
  compactContract: true,
  watchlist: [],
  denylist: [],
  signalBias: "both",
  allowWebTape: true,
  minCoverage: 0.55,
  penaltyCap: 0.75,
  sentimentMinN: 2,
  sentimentFullN: 2,
  includeJson: false,
  contractRev: 43,
  minRvol: 2,
  thinBookUsd: 50_000,
  marketMode: "spot",
  leverageVenue: "us_futures",
  marginMode: "isolated",
  maxLeverage: 3,
  liqBufferMultiple: 2,
  fundingDragR: 0.25,
  holdStyle: "intraday",
  compareInstruments: false,
  clusterCap: 2,
};
