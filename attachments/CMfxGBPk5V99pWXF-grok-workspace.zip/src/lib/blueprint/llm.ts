import type { TargetLlm } from "./types.ts";

/** Tool protocol per model. Grok discovers Coinbase, then calls exact names. */
export const LLM_TOOL_BLOCKS: Record<TargetLlm, string> = {
  grok: `Grok. If search_connected_tools is listed, call it once for Coinbase products, bid/ask, and candles. If it is not listed, you are not on connector.
call_connected_tool with the exact returned name only. Never invent search_connected_tools or a Coinbase tool.
Paginate products_list, then one bulk best_bid_ask. No per-name ticker calls. Candles 1m–1d, no 1w.
Pass B candles: entry timeframe limit ≥ 40, trend timeframe limit ≥ 30, 1d limit ≥ 22. No per-name ticker. Book limit 50 only for Pass B names.
If products_list returns no cursor, that page is the universe. Do not invent a next page.
Never orders_create. orders_preview is optional and read-only.`,
  generic:
    "Call only tools this session lists, by exact name. If none are listed, you are not on connector. Stamp the tool name and UTC. Do not paste a page address. Never invent a tool.",
  claude:
    "A public-page price is not a fill. One search per field, one retry, then na. Stamp the source name and UTC. Do not paste a page address.",
  chatgpt: "A page price is not a fill. One public source per field, then na. Stamp the source name and UTC. Do not paste a page address.",
  gemini: "Ground every number. No grounded figure → na. A page price is not a fill. Do not paste a page address.",
};
