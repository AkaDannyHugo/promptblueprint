export type UniverseMode = "marketcap" | "volume" | "perp_oi" | "category";
export type TargetLlm = "generic" | "grok" | "claude" | "chatgpt" | "gemini";
export type ProfileId = "dayTrade" | "momentum" | "meanReversion" | "balanced" | "conservative";
export type Timeframe = "15m" | "1H" | "4H" | "1D" | "1W";
export type MacroLookback = "24 hours" | "3 days" | "7 days" | "30 days";
export type SignalBias = "both" | "long" | "short";
export type MarketMode = "spot" | "leverage";
export type LeverageVenue = "us_futures" | "global_perps";
export type MarginMode = "isolated" | "cross";
export type HoldStyle = "intraday" | "session" | "swing";
export type PillarId =
  | "regime"
  | "technical"
  | "derivatives"
  | "onchain"
  | "sentiment"
  | "rr";
export type ConfigSection =
  | "universe"
  | "strategy"
  | "risk"
  | "scoring"
  | "output";

export interface CustomVar {
  id: string;
  key: string;
  value: string;
}

export interface BlueprintConfig {
  universeMode: UniverseMode;
  universeSize: 50 | 100 | 200 | 500;
  category: string;
  ecosystems: string[];
  excludeStables: boolean;
  excludeWrapped: boolean;
  excludeNew: boolean;
  minVolume: number;
  minMarketCap: number;
  minAtr: number;
  confidence: number;
  numOps: number;
  macroTf: MacroLookback;
  entryTf: Timeframe;
  trendTf: Timeframe;
  minRrr: number;
  staleness: number;
  coinbaseStaleness: number;
  atrDepthFallback: number;
  weights: Record<PillarId, number>;
  includeRefs: boolean;
  includeAudit: boolean;
  includeMetadata: boolean;
  taVsOnchain: boolean;
  taVsOnchainPenalty: number;
  taVsSentiment: boolean;
  taVsSentimentPenalty: number;
  slValidationMaxAtr: number;
  targetLlm: TargetLlm;
  profile: ProfileId | "custom";
  customVars: CustomVar[];
  darkMode: boolean;
  compactContract: boolean;
  watchlist: string[];
  denylist: string[];
  signalBias: SignalBias;
  allowWebTape: boolean;
  minCoverage: number;
  penaltyCap: number;
  sentimentMinN: number;
  sentimentFullN: number;
  includeJson: boolean;
  /** Bump when factory defaults change so a saved swing default can migrate once. */
  contractRev: number;
  /** Surge tag. Not a hard reject. */
  minRvol: number;
  /** Bid notional within 2% of mid. Below this is a tag, not a drop. */
  thinBookUsd: number;
  marketMode: MarketMode;
  leverageVenue: LeverageVenue;
  marginMode: MarginMode;
  /** Caps the idea. Not the exchange maximum. */
  maxLeverage: number;
  /** Liquidation must sit at least this many stop-distances beyond entry. */
  liqBufferMultiple: number;
  /** Drop if funding over the hold costs more than this many R. */
  fundingDragR: number;
  holdStyle: HoldStyle;
  compareInstruments: boolean;
  /** Max names kept from one category after the score. */
  clusterCap: number;
}

export interface Snapshot {
  id: string;
  name: string;
  savedAt: string;
  config: BlueprintConfig;
}

export interface Notice {
  level: "warn" | "info";
  message: string;
}
