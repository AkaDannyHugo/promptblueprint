import assert from "node:assert/strict";
import { describe, it } from "node:test";
import { DEFAULT_CONFIG, PROFILE_PATCHES } from "./constants.ts";
import { buildPrompt } from "./prompt.ts";
import type { BlueprintConfig, ProfileId } from "./types.ts";

function fromProfile(id: ProfileId, extra: Partial<BlueprintConfig> = {}): BlueprintConfig {
  const patch = PROFILE_PATCHES[id];
  return {
    ...DEFAULT_CONFIG,
    ...patch,
    weights: { ...patch.weights },
    profile: id,
    marketMode: "spot",
    ...extra,
  };
}

const SHARED = [
  "Do not score the other side",
  "0.80*regime",
  "volume_24h × connector price",
  "First match, stop at the first hit",
  "per Pass C ticker",
  "Compute ATR, RSI, VWAP, and RVOL in code",
];

describe("momentum spot contract", () => {
  const prompt = buildPrompt(fromProfile("momentum"));

  it("names the reclaim, the lock, the rank, and an off clock", () => {
    for (const needle of ["SWEEP_RECLAIM", "Time stop = off", "DATA LOCK", "Rank by expected R"]) {
      assert.ok(prompt.includes(needle), needle);
    }
  });

  it("has no page address, cash close, or HTML pillars", () => {
    assert.equal(prompt.includes("https://"), false);
    assert.equal(prompt.includes("16:00 America/New_York"), false);
    assert.equal(prompt.includes("Recency"), false);
    assert.equal(prompt.includes("Coherence"), false);
    for (const host of [
      "okx.com",
      "hyperliquid.xyz",
      "coingecko.com",
      "defillama.com",
      "cboe.com",
      "tradingview.com",
    ]) {
      assert.equal(prompt.includes(host), false, host);
    }
  });
});

describe("day-trade spot contract", () => {
  const prompt = buildPrompt(fromProfile("dayTrade"));

  it("locks the shared score rules and one VWAP anchor", () => {
    for (const needle of [
      ...SHARED,
      "09:30 America/New_York",
      "long only if last close is above",
      "Time stop = off",
    ]) {
      assert.ok(prompt.includes(needle), needle);
    }
    assert.equal(prompt.includes("[2.0,2)"), false);
    assert.equal(prompt.includes("Aligned 16"), false);
    assert.equal(prompt.includes("https://"), false);
  });
});

describe("session and leverage contracts", () => {
  it("evaluates a session stop against 16:00 America/New_York", () => {
    const prompt = buildPrompt(fromProfile("balanced", { holdStyle: "session" }));
    assert.ok(prompt.includes("16:00 America/New_York"));
    assert.ok(prompt.includes("tag SESSION_CLOSED"));
    assert.equal(prompt.includes("https://"), false);
  });

  it("keeps a leverage row on a listed contract", () => {
    const prompt = buildPrompt(fromProfile("momentum", { marketMode: "leverage" }));
    assert.ok(prompt.includes("DATA LOCK"));
    assert.ok(prompt.includes("No listed contract"));
    assert.ok(prompt.includes("liq"));
    assert.equal(prompt.includes("https://"), false);
    assert.equal(prompt.includes("[2.0,2)"), false);
  });
});
