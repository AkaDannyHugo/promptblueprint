import { create } from "zustand";
import { createJSONStorage, persist } from "zustand/middleware";
import { DEFAULT_CONFIG, PROFILE_PATCHES, TIMEFRAMES, TIMEFRAME_MINUTES } from "./constants";
import { clampWeights, normalizeWeights, snapshotName } from "./format";
import type {
  BlueprintConfig,
  ConfigSection,
  CustomVar,
  PillarId,
  ProfileId,
  Snapshot,
  Timeframe,
} from "./types";

type Patch = Partial<BlueprintConfig>;

interface BlueprintState {
  config: BlueprintConfig;
  snapshots: Snapshot[];
  section: ConfigSection;
  mobilePane: "configure" | "contract";
  hydrated: boolean;
  patch: (partial: Patch, markCustom?: boolean) => void;
  setWeight: (id: PillarId, value: number) => void;
  normalize: () => void;
  applyProfile: (id: ProfileId) => void;
  reset: () => void;
  addVar: () => void;
  updateVar: (id: string, field: "key" | "value", value: string) => void;
  removeVar: (id: string) => void;
  toggleEcosystem: (name: string) => void;
  setEntryTf: (tf: Timeframe) => void;
  setSection: (section: ConfigSection) => void;
  setMobilePane: (pane: "configure" | "contract") => void;
  saveSnapshot: (name?: string) => void;
  loadSnapshot: (id: string) => void;
  deleteSnapshot: (id: string) => void;
  importConfig: (config: BlueprintConfig) => void;
  setHydrated: () => void;
}

function withTrendGuard(config: BlueprintConfig): BlueprintConfig {
  const entry = TIMEFRAME_MINUTES[config.entryTf];
  if (TIMEFRAME_MINUTES[config.trendTf] >= entry) return config;
  const next = TIMEFRAMES.find((tf) => TIMEFRAME_MINUTES[tf] >= entry) ?? "1W";
  return { ...config, trendTf: next };
}

function cleanTickers(list?: string[] | null): string[] {
  if (!Array.isArray(list)) return [];
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of list) {
    const ticker = String(item)
      .trim()
      .toUpperCase()
      .replace(/[^A-Z0-9-]/g, "");
    if (!ticker || seen.has(ticker)) continue;
    seen.add(ticker);
    out.push(ticker);
  }
  return out.slice(0, 24);
}

function migrateWeights(
  raw?: Partial<BlueprintConfig> | null,
): BlueprintConfig["weights"] {
  const weights = { ...DEFAULT_CONFIG.weights, ...(raw?.weights ?? {}) };
  const specCard =
    (raw?.profile === "balanced" || raw?.profile == null) &&
    weights.regime === 20 &&
    weights.derivatives === 15 &&
    weights.onchain === 10 &&
    weights.rr === 15 &&
    ((weights.technical === 30 && weights.sentiment === 10) ||
      (weights.technical === 25 && weights.sentiment === 15));
  if (specCard) return { ...PROFILE_PATCHES.balanced.weights };
  const oldDayTrade =
    (raw?.profile === "dayTrade" || raw?.profile == null) &&
    weights.regime === 5 &&
    weights.technical === 35 &&
    weights.derivatives === 20 &&
    weights.onchain === 5 &&
    weights.sentiment === 20 &&
    weights.rr === 15;
  if (oldDayTrade) return { ...PROFILE_PATCHES.dayTrade.weights };
  const priorDesk =
    (raw?.profile === "dayTrade" || raw?.profile == null) &&
    weights.regime === 5 &&
    weights.technical === 40 &&
    weights.derivatives === 20 &&
    weights.onchain === 0 &&
    weights.sentiment === 20 &&
    weights.rr === 15;
  if (priorDesk) return { ...PROFILE_PATCHES.dayTrade.weights };
  return weights;
}

function isFactorySwing(raw?: Partial<BlueprintConfig> | null): boolean {
  if (!raw || (raw.profile && raw.profile !== "balanced")) return false;
  const w = raw.weights;
  if (!w) return false;
  return (
    w.regime === 20 &&
    w.technical === 25 &&
    w.derivatives === 15 &&
    w.onchain === 10 &&
    w.sentiment === 15 &&
    w.rr === 15 &&
    raw.minVolume === 5_000_000 &&
    raw.minMarketCap === 50_000_000 &&
    raw.entryTf === "4H" &&
    raw.trendTf === "1D" &&
    raw.confidence === 70 &&
    raw.minAtr === 3 &&
    raw.minRrr === 1.5 &&
    (raw.numOps === 5 || raw.numOps == null) &&
    (raw.universeMode === "volume" || raw.universeMode == null) &&
    (raw.universeSize === 50 || raw.universeSize == null) &&
    raw.excludeNew !== false
  );
}

function factoryDayTrade(raw?: Partial<BlueprintConfig> | null): BlueprintConfig {
  return withTrendGuard({
    ...DEFAULT_CONFIG,
    weights: { ...DEFAULT_CONFIG.weights },
    darkMode: raw?.darkMode !== false,
    watchlist: cleanTickers(raw?.watchlist),
    denylist: cleanTickers(raw?.denylist),
    customVars: raw?.customVars ?? [],
  });
}
function untouchedBalanced(raw?: Partial<BlueprintConfig> | null): boolean {
  if (!raw) return false;
  if (raw.profile && raw.profile !== "balanced") return false;
  const w = raw.weights;
  if (!w) return false;
  return (
    w.regime === 20 &&
    w.technical === 25 &&
    w.derivatives === 15 &&
    w.onchain === 10 &&
    w.sentiment === 15 &&
    w.rr === 15 &&
    raw.universeSize === 100 &&
    raw.compactContract === false
  );
}

function rebaseProfile(
  raw: Partial<BlueprintConfig> | null | undefined,
  id: ProfileId,
): BlueprintConfig {
  const patch = PROFILE_PATCHES[id];
  return withTrendGuard({
    ...DEFAULT_CONFIG,
    ...patch,
    weights: { ...patch.weights },
    profile: id,
    darkMode: raw?.darkMode !== false,
    watchlist: cleanTickers(raw?.watchlist),
    denylist: cleanTickers(raw?.denylist),
    customVars: raw?.customVars ?? [],
    marketMode: raw?.marketMode === "leverage" ? "leverage" : "spot",
    leverageVenue: raw?.leverageVenue === "global_perps" ? "global_perps" : "us_futures",
    marginMode: raw?.marginMode === "cross" ? "cross" : "isolated",
  });
}

function priorMomentum(raw?: Partial<BlueprintConfig> | null): boolean {
  if (raw?.profile !== "momentum" || !raw.weights) return false;
  const w = raw.weights;
  return (
    w.regime === 15 &&
    w.technical === 35 &&
    w.derivatives === 20 &&
    w.onchain === 5 &&
    w.sentiment === 10 &&
    w.rr === 15 &&
    raw.minVolume === 20_000_000 &&
    raw.minAtr === 2.5
  );
}

function priorDayDesk(raw?: Partial<BlueprintConfig> | null): boolean {
  if (!raw || (raw.profile && raw.profile !== "dayTrade") || !raw.weights) return false;
  const w = raw.weights;
  const weightsMatch =
    w.regime === 5 &&
    w.derivatives === 20 &&
    w.rr === 15 &&
    w.sentiment === 20 &&
    ((w.technical === 40 && w.onchain === 0) || (w.technical === 35 && w.onchain === 5));
  return weightsMatch && raw.entryTf === "15m" && raw.minRrr === 2;
}

const CONFIG_KEYS = [
  "universeMode",
  "universeSize",
  "category",
  "ecosystems",
  "excludeStables",
  "excludeWrapped",
  "excludeNew",
  "minVolume",
  "minMarketCap",
  "minAtr",
  "confidence",
  "numOps",
  "macroTf",
  "entryTf",
  "trendTf",
  "minRrr",
  "staleness",
  "coinbaseStaleness",
  "atrDepthFallback",
  "weights",
  "includeRefs",
  "includeAudit",
  "includeMetadata",
  "taVsOnchain",
  "taVsOnchainPenalty",
  "taVsSentiment",
  "taVsSentimentPenalty",
  "slValidationMaxAtr",
  "targetLlm",
  "profile",
  "customVars",
  "darkMode",
  "compactContract",
  "watchlist",
  "denylist",
  "signalBias",
  "allowWebTape",
  "minCoverage",
  "penaltyCap",
  "sentimentMinN",
  "sentimentFullN",
  "includeJson",
  "contractRev",
  "minRvol",
  "thinBookUsd",
  "marketMode",
  "leverageVenue",
  "marginMode",
  "maxLeverage",
  "liqBufferMultiple",
  "fundingDragR",
  "holdStyle",
  "compareInstruments",
  "clusterCap",
] as const satisfies readonly (keyof BlueprintConfig)[];

function pickKnown(raw?: Partial<BlueprintConfig> | null): Partial<BlueprintConfig> {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return {};
  const source = raw as unknown as Record<string, unknown>;
  const out: Partial<BlueprintConfig> = {};
  for (const key of CONFIG_KEYS) {
    if (source[key] !== undefined) {
      (out as Record<string, unknown>)[key] = source[key];
    }
  }
  if (out.weights && (typeof out.weights !== "object" || Array.isArray(out.weights))) {
    delete out.weights;
  }
  return out;
}

const IMPORT_ANCHORS = ["profile", "entryTf", "marketMode", "universeMode"] as const;

export function parseImportedConfig(value: unknown): BlueprintConfig | null {
  if (!value || typeof value !== "object" || Array.isArray(value)) return null;
  const raw = value as Record<string, unknown>;
  if (!raw.weights || typeof raw.weights !== "object" || Array.isArray(raw.weights)) return null;
  const weights = raw.weights as Record<string, unknown>;
  for (const id of ["regime", "technical", "derivatives", "onchain", "sentiment", "rr"] as const) {
    if (id in weights && typeof weights[id] !== "number") return null;
  }
  if (!IMPORT_ANCHORS.some((key) => key in raw)) return null;
  return hydrateConfig(pickKnown(raw as Partial<BlueprintConfig>));
}

function hydrateConfig(raw?: Partial<BlueprintConfig> | null): BlueprintConfig {
  const replacements: Array<
    (input: Partial<BlueprintConfig> | null | undefined) => BlueprintConfig | null
  > = [
    (input) =>
      (input?.contractRev ?? 0) < 41 && isFactorySwing(input) ? factoryDayTrade(input) : null,
    (input) =>
      (input?.contractRev ?? 0) < 43 && priorDayDesk(input)
        ? rebaseProfile(input, "dayTrade")
        : null,
    (input) =>
      (input?.contractRev ?? 0) < 43 && priorMomentum(input)
        ? rebaseProfile(input, "momentum")
        : null,
  ];
  for (const step of replacements) {
    const next = step(raw);
    if (next) return next;
  }
  const known = pickKnown(raw);
  const fresh = untouchedBalanced(known);
  return withTrendGuard({
    ...DEFAULT_CONFIG,
    ...known,
    weights: clampWeights(migrateWeights(known)),
    ecosystems: known.ecosystems ?? DEFAULT_CONFIG.ecosystems,
    customVars: known.customVars ?? DEFAULT_CONFIG.customVars,
    watchlist: cleanTickers(known.watchlist),
    denylist: cleanTickers(known.denylist),
    compactContract: fresh
      ? true
      : (known.compactContract ?? DEFAULT_CONFIG.compactContract),
    universeSize: fresh ? 50 : (known.universeSize ?? DEFAULT_CONFIG.universeSize),
    signalBias: known.signalBias ?? DEFAULT_CONFIG.signalBias,
    targetLlm: known.targetLlm ?? DEFAULT_CONFIG.targetLlm,
    allowWebTape: known.allowWebTape ?? DEFAULT_CONFIG.allowWebTape,
    minCoverage:
      typeof known.minCoverage === "number"
        ? known.minCoverage
        : DEFAULT_CONFIG.minCoverage,
    penaltyCap:
      typeof known.penaltyCap === "number" ? known.penaltyCap : DEFAULT_CONFIG.penaltyCap,
    sentimentMinN:
      typeof known.sentimentMinN === "number"
        ? known.sentimentMinN
        : DEFAULT_CONFIG.sentimentMinN,
    sentimentFullN:
      typeof known.sentimentFullN === "number"
        ? known.sentimentFullN
        : DEFAULT_CONFIG.sentimentFullN,
    includeJson: known.includeJson ?? DEFAULT_CONFIG.includeJson,
    contractRev: 43,
    minRvol: typeof known.minRvol === "number" ? known.minRvol : DEFAULT_CONFIG.minRvol,
    thinBookUsd:
      typeof known.thinBookUsd === "number" ? known.thinBookUsd : DEFAULT_CONFIG.thinBookUsd,
    marketMode: known.marketMode === "leverage" ? "leverage" : "spot",
    leverageVenue: known.leverageVenue === "global_perps" ? "global_perps" : "us_futures",
    marginMode: known.marginMode === "cross" ? "cross" : "isolated",
    maxLeverage:
      typeof known.maxLeverage === "number" ? known.maxLeverage : DEFAULT_CONFIG.maxLeverage,
    liqBufferMultiple:
      typeof known.liqBufferMultiple === "number"
        ? known.liqBufferMultiple
        : DEFAULT_CONFIG.liqBufferMultiple,
    fundingDragR:
      typeof known.fundingDragR === "number" ? known.fundingDragR : DEFAULT_CONFIG.fundingDragR,
    holdStyle:
      known.holdStyle === "session" ||
      known.holdStyle === "swing" ||
      known.holdStyle === "intraday"
        ? known.holdStyle
        : DEFAULT_CONFIG.holdStyle,
    compareInstruments: known.compareInstruments === true,
    clusterCap: typeof known.clusterCap === "number" ? known.clusterCap : DEFAULT_CONFIG.clusterCap,
    taVsOnchainPenalty:
      known.taVsOnchainPenalty === 0.65
        ? 0.85
        : (known.taVsOnchainPenalty ?? DEFAULT_CONFIG.taVsOnchainPenalty),
    taVsSentimentPenalty:
      known.taVsSentimentPenalty === 0.75
        ? 0.9
        : (known.taVsSentimentPenalty ?? DEFAULT_CONFIG.taVsSentimentPenalty),
  });
}

const pendingWrites = new Map<string, string>();
let flushTimer: ReturnType<typeof setTimeout> | undefined;

function flushPendingWrites() {
  if (typeof localStorage === "undefined") return;
  for (const [name, value] of pendingWrites) localStorage.setItem(name, value);
  pendingWrites.clear();
}

const deskStorage = {
  getItem(name: string) {
    if (pendingWrites.has(name)) return pendingWrites.get(name) ?? null;
    if (typeof localStorage === "undefined") return null;
    return localStorage.getItem(name);
  },
  setItem(name: string, value: string) {
    pendingWrites.set(name, value);
    if (typeof window === "undefined") return;
    if (flushTimer) clearTimeout(flushTimer);
    flushTimer = setTimeout(flushPendingWrites, 400);
  },
  removeItem(name: string) {
    pendingWrites.delete(name);
    if (typeof localStorage !== "undefined") localStorage.removeItem(name);
  },
};

if (typeof window !== "undefined") {
  window.addEventListener("pagehide", flushPendingWrites);
}

export const useBlueprint = create<BlueprintState>()(
  persist(
    (set, get) => ({
      config: DEFAULT_CONFIG,
      snapshots: [],
      section: "universe",
      mobilePane: "configure",
      hydrated: false,
      patch: (partial, markCustom = true) => {
        set((state) => {
          let config: BlueprintConfig = {
            ...state.config,
            ...partial,
            profile: markCustom ? "custom" : (partial.profile ?? state.config.profile),
          };
          config = withTrendGuard(config);
          return { config };
        });
      },
      setWeight: (id, value) => {
        set((state) => ({
          config: {
            ...state.config,
            profile: "custom",
            weights: clampWeights({ ...state.config.weights, [id]: value }),
          },
        }));
      },
      normalize: () => {
        set((state) => ({
          config: {
            ...state.config,
            weights: clampWeights(normalizeWeights(state.config.weights)),
          },
        }));
      },
      applyProfile: (id) => {
        const patch = PROFILE_PATCHES[id];
        set((state) => ({
          config: withTrendGuard({
            ...state.config,
            ...patch,
            weights: clampWeights({ ...patch.weights }),
            profile: id,
          }),
        }));
      },
      reset: () => {
        set({
          config: { ...DEFAULT_CONFIG, weights: { ...DEFAULT_CONFIG.weights } },
          section: "universe",
        });
      },
      addVar: () => {
        const item: CustomVar = {
          id:
            typeof crypto !== "undefined" && crypto.randomUUID
              ? crypto.randomUUID()
              : String(Date.now()),
          key: "",
          value: "",
        };
        set((state) => ({
          config: {
            ...state.config,
            customVars: [...state.config.customVars, item],
          },
        }));
      },
      updateVar: (id, field, value) => {
        set((state) => ({
          config: {
            ...state.config,
            customVars: state.config.customVars.map((item) =>
              item.id === id ? { ...item, [field]: value } : item,
            ),
          },
        }));
      },
      removeVar: (id) => {
        set((state) => ({
          config: {
            ...state.config,
            customVars: state.config.customVars.filter((item) => item.id !== id),
          },
        }));
      },
      toggleEcosystem: (name) => {
        set((state) => {
          const has = state.config.ecosystems.includes(name);
          return {
            config: {
              ...state.config,
              profile: "custom",
              ecosystems: has
                ? state.config.ecosystems.filter((e) => e !== name)
                : [...state.config.ecosystems, name],
            },
          };
        });
      },
      setEntryTf: (tf) => {
        set((state) => ({
          config: withTrendGuard({
            ...state.config,
            entryTf: tf,
            profile: "custom",
          }),
        }));
      },
      setSection: (section) => set({ section }),
      setMobilePane: (mobilePane) => set({ mobilePane }),
      saveSnapshot: (name) => {
        const { config } = get();
        const snap: Snapshot = {
          id:
            typeof crypto !== "undefined" && crypto.randomUUID
              ? crypto.randomUUID()
              : String(Date.now()),
          name: name?.trim() || snapshotName(config),
          savedAt: new Date().toISOString(),
          config: structuredClone(config),
        };
        set((state) => ({
          snapshots: [snap, ...state.snapshots].slice(0, 16),
        }));
      },
      loadSnapshot: (id) => {
        const snap = get().snapshots.find((s) => s.id === id);
        if (!snap) return;
        set({ config: hydrateConfig(snap.config) });
      },
      deleteSnapshot: (id) => {
        set((state) => ({
          snapshots: state.snapshots.filter((s) => s.id !== id),
        }));
      },
      importConfig: (config) => {
        set({ config: hydrateConfig(config) });
      },
      setHydrated: () => set({ hydrated: true }),
    }),
    {
      name: "prompt-blueprint-v3",
      storage: createJSONStorage(() => deskStorage),
      partialize: (state) => ({
        config: state.config,
        snapshots: state.snapshots,
      }),
      merge: (persisted, current) => {
        const p = persisted as
          | { config?: BlueprintConfig; snapshots?: Snapshot[] }
          | undefined;
        return {
          ...current,
          ...p,
          config: hydrateConfig(p?.config),
          snapshots: p?.snapshots ?? current.snapshots,
        };
      },
      onRehydrateStorage: () => (state) => {
        if (state) state.config = hydrateConfig(state.config);
        state?.setHydrated();
      },
    },
  ),
);
