import { useState } from "react";
import { X } from "lucide-react";
import { toast } from "sonner";
import {
  CATEGORIES,
  ECOSYSTEMS,
  UNIVERSE_MODES,
} from "@/lib/blueprint/constants";
import { parseTickerInput } from "@/lib/blueprint/format";
import { useBlueprint } from "@/lib/blueprint/store";
import type { UniverseMode } from "@/lib/blueprint/types";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Card, Field, SelectField } from "./field";
import { QuietEmpty } from "./states";
import { cn } from "@/lib/utils";

export function UniverseSection() {
  const config = useBlueprint((s) => s.config);
  const patch = useBlueprint((s) => s.patch);
  const toggleEcosystem = useBlueprint((s) => s.toggleEcosystem);

  return (
    <>
      <Card title="Universe & segment">
        <SelectField
          id="universe-mode"
          label="Universe mode"
          hint={
            config.universeMode === "perp_oi"
              ? config.marketMode === "leverage"
                ? "Pass A maps to listed contracts, then ranks by open interest. Missing OI falls back to spot volume and is tagged."
                : "Pass A still ranks Coinbase spot by volume. Open interest is read later, for the short list only."
              : "How the list is built."
          }
          value={config.universeMode}
          onChange={(v) => patch({ universeMode: v as UniverseMode })}
        >
          {UNIVERSE_MODES.map((m) => (
            <option key={m.id} value={m.id}>
              {m.label}
            </option>
          ))}
        </SelectField>
        <SelectField
          id="universe-size"
          label="Universe size"
          value={String(config.universeSize)}
          onChange={(v) =>
            patch({ universeSize: Number(v) as 50 | 100 | 200 | 500 })
          }
        >
          {[50, 100, 200, 500].map((n) => (
            <option key={n} value={n}>
              Top {n}
            </option>
          ))}
        </SelectField>
        <SelectField
          id="asset-category"
          label="Asset category"
          hint="Only used in category mode."
          value={config.category}
          onChange={(v) => patch({ category: v })}
        >
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>
              {c === "any" ? "Any category" : c}
            </option>
          ))}
        </SelectField>
      </Card>

      <Card title="Filters & exclusions">
        <Field label="Ecosystem filter">
          <div className="flex flex-wrap gap-2">
            {ECOSYSTEMS.map((name) => {
              const on = config.ecosystems.includes(name);
              return (
                <button
                  key={name}
                  type="button"
                  aria-pressed={on}
                  onClick={() => toggleEcosystem(name)}
                  className={cn(
                    "pressable h-11 rounded-full px-3 text-xs font-medium select-none",
                    on
                      ? "bg-accent text-accent-fg"
                      : "bg-elevated text-muted shadow-[var(--shadow-border)] hover:text-fg",
                  )}
                >
                  {name}
                </button>
              );
            })}
          </div>
        </Field>
        <fieldset className="grid gap-3">
          <legend className="text-xs font-medium uppercase tracking-widest text-muted">
            Default exclusions
          </legend>
          <Exclusion
            id="exclude-stables"
            label="Exclude stablecoins"
            checked={config.excludeStables}
            onChange={(v) => patch({ excludeStables: v })}
          />
          <Exclusion
            id="exclude-wrapped"
            label="Exclude wrapped assets"
            checked={config.excludeWrapped}
            onChange={(v) => patch({ excludeWrapped: v })}
          />
          <Exclusion
            id="exclude-new"
            label="Exclude new listings (<30d)"
            checked={config.excludeNew}
            onChange={(v) => patch({ excludeNew: v })}
          />
        </fieldset>
      </Card>

      <TickerListCard
        title="Watchlist"
        hint="Bases. Spot uses the USD product. Leverage maps the base to a listed contract."
        values={config.watchlist ?? []}
        onChange={(watchlist) => patch({ watchlist })}
        placeholder="ETH-USD, SOL-USD"
      />
      <TickerListCard
        title="Denylist"
        hint="Matches the base or the full product id. ETH-USD denies ETH."
        values={config.denylist ?? []}
        onChange={(denylist) => patch({ denylist })}
        placeholder="DOGE-USD"
      />
    </>
  );
}

function TickerListCard({
  title,
  hint,
  values,
  onChange,
  placeholder,
}: {
  title: string;
  hint: string;
  values: string[];
  onChange: (next: string[]) => void;
  placeholder: string;
}) {
  const [draft, setDraft] = useState("");

  function add() {
    const incoming = parseTickerInput(draft);
    if (!incoming.length) {
      if (draft.trim()) toast.error("Use a product ID like ETH-USD");
      return;
    }
    const seen = new Set(values);
    const next = [...values];
    let added = 0;
    for (const ticker of incoming) {
      if (seen.has(ticker)) continue;
      if (next.length >= 24) break;
      seen.add(ticker);
      next.push(ticker);
      added += 1;
    }
    if (!added) {
      toast.error(values.length >= 24 ? "List is full at 24 names" : "Already on the list");
      return;
    }
    if (added < incoming.length) toast("Some names were already listed");
    onChange(next);
    setDraft("");
  }

  return (
    <Card title={title}>
      <Field label="Tickers" hint={hint}>
        <div className="flex gap-2">
          <Input
            value={draft}
            placeholder={placeholder}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter") {
                e.preventDefault();
                add();
              }
            }}
            aria-label={`${title} tickers`}
          />
          <Button variant="secondary" onClick={add} disabled={!draft.trim()}>
            Add
          </Button>
        </div>
      </Field>
      {values.length ? (
        <div className="flex flex-wrap gap-2">
          {values.map((ticker) => (
            <button
              key={ticker}
              type="button"
              className="pressable notice-in inline-flex h-11 items-center gap-1.5 rounded-full bg-elevated px-3 text-xs font-medium text-fg shadow-[var(--shadow-border)]"
              onClick={() => onChange(values.filter((item) => item !== ticker))}
            >
              {ticker}
              <X className="size-3" />
            </button>
          ))}
        </div>
      ) : (
        <QuietEmpty>None yet.</QuietEmpty>
      )}
    </Card>
  );
}

function Exclusion({
  id,
  label,
  checked,
  onChange,
}: {
  id: string;
  label: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex min-h-11 items-center gap-3">
      <Checkbox
        id={id}
        checked={checked}
        onCheckedChange={(v) => onChange(v === true)}
      />
      <label htmlFor={id} className="text-sm text-fg">
        {label}
      </label>
    </div>
  );
}
