import { useEffect, useRef, useState } from "react";
import { Check, Copy, Download } from "lucide-react";
import { toast } from "sonner";
import { APP_VERSION } from "@/lib/blueprint/constants";
import { buildPrompt } from "@/lib/blueprint/prompt";
import { copyText, downloadText, estimateTokens, formatCount, weightTotal } from "@/lib/blueprint/format";
import { useBlueprint } from "@/lib/blueprint/store";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { IconSwap } from "./states";

type CopyPhase = "idle" | "copied" | "failed";

export function PromptPane() {
  const config = useBlueprint((s) => s.config);
  const mobilePane = useBlueprint((s) => s.mobilePane);
  const [prompt, setPrompt] = useState(() => buildPrompt(config));
  const [copyPhase, setCopyPhase] = useState<CopyPhase>("idle");
  const copyTimer = useRef<number | null>(null);
  const copyRef = useRef<() => void>(() => {});

  function currentPrompt() {
    return buildPrompt(config, {
      generatedAt: config.includeMetadata ? new Date().toISOString() : undefined,
    });
  }

  useEffect(() => {
    setPrompt(currentPrompt());
    // The stamp is refreshed again at copy and export.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [config]);

  useEffect(() => {
    return () => {
      if (copyTimer.current) window.clearTimeout(copyTimer.current);
    };
  }, []);

  copyRef.current = () => {
    void onCopy();
  };

  useEffect(() => {
    function onKey(event: KeyboardEvent) {
      if (!(event.metaKey || event.ctrlKey) || event.key.toLowerCase() !== "c") return;
      const target = event.target;
      if (
        target instanceof HTMLElement &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.tagName === "SELECT" ||
          target.isContentEditable)
      ) {
        return;
      }
      if (window.getSelection()?.toString()) return;
      const narrow = window.matchMedia("(max-width: 1023px)").matches;
      if (narrow && mobilePane !== "contract") return;
      event.preventDefault();
      copyRef.current();
    }
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [mobilePane]);

  function onExport() {
    const text = currentPrompt();
    setPrompt(text);
    downloadText("prompt-blueprint.txt", text, "text/plain;charset=utf-8");
    toast.success("Exported as text");
  }

  async function onCopy() {
    const text = currentPrompt();
    setPrompt(text);
    const ok = await copyText(text);
    if (copyTimer.current) window.clearTimeout(copyTimer.current);
    if (ok) {
      setCopyPhase("copied");
      toast.success("Contract copied");
      copyTimer.current = window.setTimeout(() => setCopyPhase("idle"), 1400);
    } else {
      setCopyPhase("failed");
      toast.error("Could not copy. Select the contract and copy it manually.");
      copyTimer.current = window.setTimeout(() => setCopyPhase("idle"), 2000);
    }
  }

  const tokens = estimateTokens(prompt);
  const weightSum = weightTotal(config);
  const lev = config.marketMode === "leverage";
  const badge = !lev ? "SPOT" : config.leverageVenue === "global_perps" ? "LEV · GLOBAL" : "LEV · US";
  const hot = lev && config.maxLeverage > 5;

  return (
    <>
      <h2 id="contract-heading" className="sr-only">
        Contract
      </h2>
      <div className="flex h-full min-h-0 flex-col">
      <div className="flex flex-wrap items-center gap-2 border-b border-border px-4 py-3">
        <div className="mr-auto flex items-center gap-2 font-mono text-xs tabular-nums text-muted">
          <span
            className={cn(
              "rounded-full px-2 py-1 text-[11px] font-medium tracking-wide",
              hot ? "bg-warn/15 text-warn" : "bg-elevated text-fg",
            )}
          >
            {badge}
          </span>
          <span>
            v{APP_VERSION} · {formatCount(prompt.length)} chars · ~{formatCount(tokens)} tok
            <span className="hidden text-subtle sm:inline"> · role, tools, steps, schema</span>
          </span>
        </div>
        <Button variant="secondary" size="sm" onClick={onCopy}>
          <IconSwap show={copyPhase === "copied"} alt={<Copy className="size-3.5" />}>
            <Check className="size-3.5" />
          </IconSwap>
          {copyPhase === "copied" ? "Copied" : copyPhase === "failed" ? "Copy failed" : "Copy"}
        </Button>
        <Button variant="secondary" size="sm" onClick={onExport}>
          <Download className="size-3.5" />
          Export
        </Button>
        <span className="sr-only" aria-live="polite">
          {copyPhase === "copied" ? "Contract copied" : copyPhase === "failed" ? "Copy failed" : ""}
        </span>
        {weightSum !== 100 ? (
          <span className="rounded-full bg-warn/15 px-2.5 py-1 text-xs font-medium text-warn">
            Weights {weightSum}
          </span>
        ) : null}
      </div>
      <pre
        className="min-h-0 flex-1 overflow-auto whitespace-pre-wrap break-words px-5 py-5 font-mono text-xs leading-relaxed text-fg"
        aria-label="Generated prompt"
      >
        {prompt}
      </pre>
    </div>
    </>
  );
}
