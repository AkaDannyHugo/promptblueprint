import { formatUsd } from "@/lib/blueprint/format";
import { useBlueprint } from "@/lib/blueprint/store";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, SliderField } from "./field";

export function RiskSection() {
  const config = useBlueprint((s) => s.config);
  const patch = useBlueprint((s) => s.patch);

  return (
    <>
      <Card title="Risk & data gates">
        <SliderField
          id="min-volume"
          label="Min 24h volume"
          hint="Dollar floor only. A surge is tagged with relative volume. It does not delete a liquid major."
          value={config.minVolume}
          display={formatUsd(config.minVolume)}
          min={1_000_000}
          max={500_000_000}
          step={1_000_000}
          onChange={(v) => patch({ minVolume: v })}
        />
        <SliderField
          id="min-mcap"
          label="Min market cap"
          hint="Opens Coinbase mid-caps. A thin book is tagged from 2% bid depth, not rejected."
          value={config.minMarketCap}
          display={formatUsd(config.minMarketCap)}
          min={5_000_000}
          max={2_000_000_000}
          step={5_000_000}
          onChange={(v) => patch({ minMarketCap: v })}
        />
        <SliderField
          id="min-atr"
          label="Min ATR percent"
          hint="15m or 1H ATR. The floor skips a dead tape. A violent tape is tagged, not required."
          value={config.minAtr}
          display={`${config.minAtr.toFixed(1)}%`}
          min={0.2}
          max={25}
          step={0.1}
          onChange={(v) => patch({ minAtr: v })}
        />
        <SliderField
          id="atr-depth"
          label="ATR-NA depth fallback"
          hint="Used only when ATR cannot be fetched."
          value={config.atrDepthFallback}
          display={formatUsd(config.atrDepthFallback)}
          min={25_000}
          max={250_000}
          step={5_000}
          onChange={(v) => patch({ atrDepthFallback: v })}
        />
        <SliderField
          id="rvol"
          label="RVOL surge tag"
          hint="Today versus the prior 20 sessions. A tag and a tie-break, not a gate. 2× is the usual day-trade bar."
          value={config.minRvol}
          display={`${config.minRvol.toFixed(1)}×`}
          min={1}
          max={5}
          step={0.5}
          onChange={(v) => patch({ minRvol: v })}
        />
        <SliderField
          id="thin-book"
          label="Thin-book flag"
          hint="Bids within 2% of mid under this are tagged THIN_BOOK. The name stays."
          value={config.thinBookUsd}
          display={formatUsd(config.thinBookUsd)}
          min={25_000}
          max={250_000}
          step={5_000}
          onChange={(v) => patch({ thinBookUsd: v })}
        />
        <SliderField
          id="cb-staleness"
          label="Coinbase staleness"
          hint="Older ticker or book prints are ignored."
          value={config.coinbaseStaleness}
          display={`${config.coinbaseStaleness} min`}
          min={5}
          max={60}
          step={5}
          onChange={(v) => patch({ coinbaseStaleness: v })}
        />
        <SliderField
          id="staleness"
          label="Free-source staleness"
          hint="Web prints older than this are na. A page is not a fill."
          value={config.staleness}
          display={`${config.staleness} min`}
          min={30}
          max={180}
          step={5}
          onChange={(v) => patch({ staleness: v })}
        />
        <SliderField
          id="sl-atr"
          label="SL validation (ATR multiple)"
          hint="Flags a wide stop. Does not reject it."
          value={config.slValidationMaxAtr}
          display={`${config.slValidationMaxAtr.toFixed(1)}x`}
          min={1.5}
          max={5}
          step={0.1}
          onChange={(v) => patch({ slValidationMaxAtr: v })}
        />
      </Card>

      {config.marketMode === "leverage" ? (
        <Card title="Leverage gates">
          <SliderField
            id="liq-buffer"
            label="Liquidation buffer"
            hint="Liquidation must sit at least this many times the stop distance beyond entry. Else cut leverage. Do not widen the stop."
            value={config.liqBufferMultiple}
            display={`${config.liqBufferMultiple}×`}
            min={1.5}
            max={3}
            step={0.5}
            onChange={(v) => patch({ liqBufferMultiple: v })}
          />
          <SliderField
            id="funding-drag"
            label="Funding-drag reject"
            hint="If the planned hold pays more than this in funding, drop. Dated futures use basis, not funding."
            value={config.fundingDragR}
            display={`${config.fundingDragR.toFixed(2)}R`}
            min={0.1}
            max={0.5}
            step={0.05}
            onChange={(v) => patch({ fundingDragR: Math.round(v * 100) / 100 })}
          />
          {config.holdStyle === "session" || config.holdStyle === "swing" ? (
            <p className="rounded-md bg-elevated px-3 py-2 text-sm leading-relaxed text-muted">
              Hold can cross 16:00 ET. US futures use overnight margin, not the intraday rate.
            </p>
          ) : null}
        </Card>
      ) : null}

      <Card title="Divergence guardrails">
        <Penalty
          id="ta-onchain"
          label="TA vs on-chain penalty"
          checked={config.taVsOnchain}
          onCheck={(v) => patch({ taVsOnchain: v })}
          value={config.taVsOnchainPenalty}
          onValue={(v) => patch({ taVsOnchainPenalty: v })}
        />
        <Penalty
          id="ta-sentiment"
          label="TA vs sentiment penalty"
          checked={config.taVsSentiment}
          onCheck={(v) => patch({ taVsSentiment: v })}
          value={config.taVsSentimentPenalty}
          onValue={(v) => patch({ taVsSentimentPenalty: v })}
        />
        <SliderField
          id="penalty-cap"
          label="Penalty floor"
          hint="Penalties cannot multiply below this."
          value={config.penaltyCap ?? 0.75}
          display={(config.penaltyCap ?? 0.75).toFixed(2)}
          min={0.5}
          max={1}
          step={0.05}
          onChange={(v) => patch({ penaltyCap: v })}
        />
      </Card>
    </>
  );
}

function Penalty({
  id,
  label,
  checked,
  onCheck,
  value,
  onValue,
}: {
  id: string;
  label: string;
  checked: boolean;
  onCheck: (v: boolean) => void;
  value: number;
  onValue: (v: number) => void;
}) {
  return (
    <div className="grid gap-2">
      <div className="flex min-h-11 items-center gap-3">
        <Checkbox
          id={id}
          checked={checked}
          onCheckedChange={(v) => onCheck(v === true)}
        />
        <label htmlFor={id} className="text-sm text-fg">
          {label}
        </label>
      </div>
      {checked ? (
        <SliderField
          id={`${id}-mult`}
          label="Penalty multiplier"
          value={value}
          display={value.toFixed(2)}
          min={0.1}
          max={1}
          step={0.05}
          onChange={onValue}
        />
      ) : null}
    </div>
  );
}
