import { useEffect, useRef, useState } from "react";
import {
  BookOpen,
  Bookmark,
  History,
  Moon,
  RotateCcw,
  Sun,
  Upload,
  BookmarkPlus,
} from "lucide-react";
import { toast } from "sonner";
import { PROFILE_META } from "@/lib/blueprint/constants";
import { profileLabel, snapshotName } from "@/lib/blueprint/format";
import { useBlueprint, parseImportedConfig } from "@/lib/blueprint/store";
import type { BlueprintConfig, MarketMode, ProfileId } from "@/lib/blueprint/types";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { GuideBody } from "./guide-dialog";
import { EmptyState, IconSwap } from "./states";
import { cn } from "@/lib/utils";

const PROFILES = Object.keys(PROFILE_META) as ProfileId[];

function subtitle(config: BlueprintConfig): string {
  const desk = profileLabel(config);
  if (config.marketMode === "leverage") {
    const book = config.leverageVenue === "global_perps" ? "global perps" : "US futures";
    return `${desk} · ${book}`;
  }
  return `${desk} · spot screen`;
}

export function AppHeader() {
  const config = useBlueprint((s) => s.config);
  const patch = useBlueprint((s) => s.patch);
  const applyProfile = useBlueprint((s) => s.applyProfile);
  const reset = useBlueprint((s) => s.reset);
  const snapshots = useBlueprint((s) => s.snapshots);
  const saveSnapshot = useBlueprint((s) => s.saveSnapshot);
  const loadSnapshot = useBlueprint((s) => s.loadSnapshot);
  const deleteSnapshot = useBlueprint((s) => s.deleteSnapshot);
  const importConfig = useBlueprint((s) => s.importConfig);
  const fileRef = useRef<HTMLInputElement>(null);
  const [guideOpen, setGuideOpen] = useState(false);
  const [historyOpen, setHistoryOpen] = useState(false);
  const [resetOpen, setResetOpen] = useState(false);
  const [pendingDelete, setPendingDelete] = useState<string | null>(null);
  const [snapName, setSnapName] = useState("");

  useEffect(() => {
    if (!historyOpen) setPendingDelete(null);
  }, [historyOpen]);

  function onReset() {
    reset();
    toast.success("Reset to the day-trade spot default");
  }

  function onSave() {
    saveSnapshot(snapName);
    setSnapName("");
    toast.success("Snapshot saved");
  }

  function onExportConfig() {
    const blob = new Blob([JSON.stringify(config, null, 2)], {
      type: "application/json",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "prompt-blueprint-config.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  function onImportFile(file: File) {
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = parseImportedConfig(JSON.parse(String(reader.result)));
        if (!parsed) throw new Error("bad");
        importConfig(parsed);
        toast.success("Config imported");
        setHistoryOpen(false);
      } catch {
        toast.error("That file is not a valid blueprint config");
      }
    };
    reader.readAsText(file);
  }

  return (
    <header className="shrink-0 border-b border-border bg-bg/80 backdrop-blur-sm">
      <div className="flex flex-wrap items-center gap-2 px-4 py-3 lg:px-6">
        <div className="flex w-full min-w-0 items-center gap-2 sm:w-auto sm:gap-3">
          <Mark />
          <div className="min-w-0 flex-1 sm:flex-none">
            <h1 className="truncate font-display text-lg font-semibold leading-none tracking-tight sm:text-xl">
              Prompt Blueprint
            </h1>
            <p className="mt-1 truncate font-mono text-[11px] text-muted sm:text-xs">
              {subtitle(config)}
            </p>
          </div>
        </div>

        <div
          className="flex h-11 shrink-0 rounded-full bg-elevated p-0.5 shadow-[var(--shadow-border)]"
          role="group"
          aria-label="Market"
        >
          {(
            [
              ["spot", "Spot"],
              ["leverage", "Leverage"],
            ] as const
          ).map(([id, label]) => {
            const on = (config.marketMode ?? "spot") === id;
            return (
              <button
                key={id}
                type="button"
                aria-pressed={on}
                onClick={() => patch({ marketMode: id as MarketMode }, false)}
                className={cn(
                  "pressable h-10 rounded-full px-3 text-xs font-medium select-none",
                  on ? "bg-accent text-accent-fg" : "text-muted hover:text-fg",
                )}
              >
                {label}
              </button>
            );
          })}
        </div>

        <div className="ml-auto flex flex-wrap items-center gap-1.5">
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label={config.darkMode ? "Switch to light mode" : "Switch to dark mode"}
            onClick={() => {
              const next = !config.darkMode;
              patch({ darkMode: next }, false);
              document.documentElement.classList.toggle("dark", next);
              document.documentElement.classList.toggle("light", !next);
            }}
          >
            <IconSwap show={config.darkMode} alt={<Moon className="size-4" />}>
              <Sun className="size-4" />
            </IconSwap>
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Guide"
            onClick={() => setGuideOpen(true)}
          >
            <BookOpen className="size-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Snapshots"
            onClick={() => setHistoryOpen(true)}
          >
            <History className="size-4" />
          </Button>
          <Button
            variant="ghost"
            size="icon-sm"
            aria-label="Reset to defaults"
            onClick={() => setResetOpen(true)}
          >
            <RotateCcw className="size-4" />
          </Button>
        </div>
      </div>

      <div className="no-scrollbar flex gap-1 overflow-x-auto px-4 pb-3 lg:px-6">
        {PROFILES.map((id) => {
          const on = config.profile === id;
          return (
            <button
              key={id}
              type="button"
              aria-pressed={on}
              onClick={() => applyProfile(id)}
              className={cn(
                "pressable h-11 shrink-0 rounded-full px-3 text-xs font-medium select-none",
                on
                  ? "bg-accent text-accent-fg"
                  : "text-muted hover:bg-elevated hover:text-fg",
              )}
            >
              {PROFILE_META[id].label}
            </button>
          );
        })}
        {config.profile === "custom" ? (
          <span className="notice-in inline-flex h-11 items-center rounded-full px-3 text-xs text-accent">
            Custom
          </span>
        ) : null}
      </div>

      <Dialog open={guideOpen} onOpenChange={setGuideOpen}>
        <DialogContent title="Blueprint guide">
          <GuideBody />
        </DialogContent>
      </Dialog>

      <Dialog open={resetOpen} onOpenChange={setResetOpen}>
        <DialogContent title="Reset this blueprint?">
          <p className="text-sm leading-relaxed text-muted">
            Every control returns to the day-trade spot default. Saved snapshots stay.
          </p>
          <div className="mt-5 flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setResetOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={() => {
                onReset();
                setResetOpen(false);
              }}
            >
              Reset
            </Button>
          </div>
        </DialogContent>
      </Dialog>

      <Dialog open={historyOpen} onOpenChange={setHistoryOpen}>
        <DialogContent title="Snapshots">
          <div className="grid gap-4">
            <div className="flex gap-2">
              <Input
                placeholder={snapshotName(config)}
                value={snapName}
                onChange={(e) => setSnapName(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter") onSave();
                }}
                aria-label="Snapshot name"
              />
              <Button onClick={onSave}>
                <BookmarkPlus className="size-4" />
                Save
              </Button>
            </div>
            <div className="flex gap-2">
              <Button variant="secondary" size="sm" onClick={onExportConfig}>
                Export JSON
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={() => fileRef.current?.click()}
              >
                <Upload className="size-4" />
                Import
              </Button>
              <input
                ref={fileRef}
                type="file"
                accept="application/json"
                className="hidden"
                onChange={(e) => {
                  const file = e.target.files?.[0];
                  if (file) onImportFile(file);
                  e.target.value = "";
                }}
              />
            </div>
            {snapshots.length === 0 ? (
              <EmptyState
                icon={Bookmark}
                title="No snapshots yet"
                body="Saved in this browser only. Not an account."
              />
            ) : (
              <ul className="grid gap-2">
                {snapshots.map((snap) => (
                  <li
                    key={snap.id}
                    className="notice-in flex items-center gap-2 rounded-lg bg-elevated px-3 py-2 shadow-[var(--shadow-border)]"
                  >
                    <div className="min-w-0 flex-1">
                      <div className="truncate text-sm text-fg">{snap.name}</div>
                      <div className="font-mono text-xs text-muted">
                        {new Date(snap.savedAt).toLocaleString()}
                      </div>
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => {
                        loadSnapshot(snap.id);
                        setHistoryOpen(false);
                        toast.success("Snapshot loaded");
                      }}
                    >
                      Load
                    </Button>
                    <Button
                      variant={pendingDelete === snap.id ? "danger" : "ghost"}
                      size="sm"
                      onClick={() => {
                        if (pendingDelete !== snap.id) {
                          setPendingDelete(snap.id);
                          return;
                        }
                        deleteSnapshot(snap.id);
                        setPendingDelete(null);
                        toast.success("Snapshot removed");
                      }}
                    >
                      {pendingDelete === snap.id ? "Confirm" : "Delete"}
                    </Button>
                  </li>
                ))}
              </ul>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </header>
  );
}

function Mark() {
  return (
    <svg
      viewBox="0 0 32 32"
      className="size-9 text-fg"
      aria-hidden="true"
    >
      <rect x="3" y="3" width="26" height="26" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <path d="M3 9h4M9 3v4M29 23h-4M23 29v-4" stroke="currentColor" strokeWidth="1.4" />
      <path d="M10 22V10h8l4 4v8H10z" fill="none" stroke="currentColor" strokeWidth="1.4" />
      <path d="M18 10v4h4" fill="none" stroke="currentColor" strokeWidth="1.4" />
    </svg>
  );
}
