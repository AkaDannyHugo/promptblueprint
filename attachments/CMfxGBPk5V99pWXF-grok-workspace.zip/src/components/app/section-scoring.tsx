import { PILLARS } from "@/lib/blueprint/constants";
import { weightTotal } from "@/lib/blueprint/format";
import { useBlueprint } from "@/lib/blueprint/store";
import { Button } from "@/components/ui/button";
import { Card, SliderField } from "./field";
import { WeightBar } from "./weight-bar";
import { cn } from "@/lib/utils";

export function ScoringSection() {
  const config = useBlueprint((s) => s.config);
  const setWeight = useBlueprint((s) => s.setWeight);
  const patch = useBlueprint((s) => s.patch);
  const normalize = useBlueprint((s) => s.normalize);
  const total = weightTotal(config);

  return (
    <>
      <Card title="FINCOT scoring">
        <div className="flex items-center justify-between gap-3">
          <p className="text-sm text-muted">Must sum to 100. Missing data is dropped, not scored as zero.</p>
          <span
            className={cn(
              "font-mono text-sm tabular-nums transition-colors duration-[var(--motion-quick)]",
              total === 100 ? "text-accent" : "text-warn",
            )}
          >
            {total}%
          </span>
        </div>
        <WeightBar weights={config.weights} />
        {total !== 100 ? (
          <Button variant="secondary" size="sm" className="notice-in" onClick={normalize}>
            Normalize to 100%
          </Button>
        ) : null}
        {PILLARS.map((p) => (
          <SliderField
            key={p.id}
            id={`w-${p.id}`}
            label={`${p.label} (max ${p.max})`}
            value={config.weights[p.id]}
            display={`${config.weights[p.id]}%`}
            min={0}
            max={p.max}
            step={5}
            onChange={(v) => setWeight(p.id, v)}
          />
        ))}
      </Card>
      <Card title="Conviction floors">
        <SliderField
          id="confidence"
          label="Min confidence threshold"
          hint="The profile side must clear this floor. An empty table is valid. Coverage still blocks a thin case."
          value={config.confidence}
          display={`${config.confidence}%`}
          min={50}
          max={95}
          step={1}
          onChange={(v) => patch({ confidence: v })}
        />
        <SliderField
          id="min-rrr"
          label="Minimum R/R ratio"
          hint="Continuation or a sweep-reclaim must clear this R. Do not score the other side to print it."
          value={config.minRrr}
          display={config.minRrr.toFixed(1)}
          min={1}
          max={5}
          step={0.1}
          onChange={(v) => patch({ minRrr: v })}
        />
        <SliderField
          id="min-coverage"
          label="Minimum coverage"
          hint="Technical and reward-to-risk only."
          value={Math.round((config.minCoverage ?? 0.55) * 100)}
          display={`${Math.round((config.minCoverage ?? 0.55) * 100)}%`}
          min={40}
          max={80}
          step={5}
          onChange={(v) => patch({ minCoverage: v / 100 })}
        />
        <SliderField
          id="sentiment-n"
          label="Sentiment posts required"
          hint="Fewer posts and sentiment is dropped."
          value={config.sentimentMinN ?? 2}
          display={String(config.sentimentMinN ?? 2)}
          min={2}
          max={16}
          step={1}
          onChange={(v) =>
            patch({
              sentimentMinN: v,
              sentimentFullN: Math.max(v, config.sentimentFullN ?? v),
            })
          }
        />
        <SliderField
          id="sentiment-full-n"
          label="Sentiment posts for full weight"
          hint="Between the minimum and this count, the pillar is scaled. At this count it is full."
          value={Math.max(config.sentimentFullN ?? 2, config.sentimentMinN ?? 2)}
          display={String(Math.max(config.sentimentFullN ?? 2, config.sentimentMinN ?? 2))}
          min={config.sentimentMinN ?? 2}
          max={16}
          step={1}
          onChange={(v) => patch({ sentimentFullN: v })}
        />
      </Card>
    </>
  );
}
