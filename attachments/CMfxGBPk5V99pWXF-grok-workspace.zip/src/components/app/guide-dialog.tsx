export function GuideBody() {
  return (
    <div className="grid gap-5 text-sm leading-relaxed text-muted">
      <p>
        Spot is the default. It is a same-day screen: 15-minute entries, a 1-hour trend, and a 60% floor. A thin book or a loud tape is tagged, not deleted. Paste it into Grok with Coinbase connected. It does not place trades.
      </p>
      <p>
        Leverage is the header switch. It asks for a listed US future or a global {"{BASE}"}_USDC-PERPETUAL, caps leverage, and drops a name whose liquidation sits inside the stop buffer or whose funding drag eats the R. Shorts are real only on that contract. INTX ids are not used.
      </p>
      <p>
        The contract is ordered for that model: role and hard bounds, then the tool sequence, then numbered steps, then the scoring rules, then the exact output schema. Grok is told to reason privately and print only that schema.
      </p>
      <p>
        Six pillars. Missing data is dropped, not scored as zero. Sentiment
        cannot clear the gate by itself. Zero names is a valid result. An empty table is a valid scan. A red book may print one sweep-reclaim long. It must not print both sides, and a spot short stays research-only.
      </p>
    </div>
  );
}
