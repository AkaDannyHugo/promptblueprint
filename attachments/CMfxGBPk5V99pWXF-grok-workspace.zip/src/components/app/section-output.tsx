import { Plus, X } from "lucide-react";
import { LLM_OPTIONS } from "@/lib/blueprint/constants";
import { useBlueprint } from "@/lib/blueprint/store";
import type { TargetLlm } from "@/lib/blueprint/types";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import { Card, SelectField } from "./field";
import { QuietEmpty } from "./states";

export function OutputSection() {
  const config = useBlueprint((s) => s.config);
  const patch = useBlueprint((s) => s.patch);
  const addVar = useBlueprint((s) => s.addVar);
  const updateVar = useBlueprint((s) => s.updateVar);
  const removeVar = useBlueprint((s) => s.removeVar);

  return (
    <>
      <Card title="Target LLM">
        <SelectField
          id="target-llm"
          label="Model"
          value={config.targetLlm}
          onChange={(v) => patch({ targetLlm: v as TargetLlm }, false)}
        >
          {LLM_OPTIONS.map((o) => (
            <option key={o.id} value={o.id}>
              {o.label}
            </option>
          ))}
        </SelectField>
        <p className="text-sm text-muted">
          {LLM_OPTIONS.find((o) => o.id === config.targetLlm)?.hint}
        </p>
      </Card>

      <Card title="Contract options">
        <Toggle
          id="metadata"
          label="Include timestamp"
          checked={config.includeMetadata}
          onChange={(v) => patch({ includeMetadata: v }, false)}
        />
        <Toggle
          id="refs"
          label="References"
          checked={config.includeRefs}
          onChange={(v) => patch({ includeRefs: v }, false)}
        />
        <Toggle
          id="audit"
          label="Source list"
          checked={config.includeAudit}
          onChange={(v) => patch({ includeAudit: v }, false)}
        />
        <Toggle
          id="webtape"
          label="Allow web prices"
          checked={config.allowWebTape !== false}
          onChange={(v) => patch({ allowWebTape: v }, false)}
        />
        <Toggle
          id="json"
          label="JSON block"
          checked={config.includeJson === true}
          onChange={(v) => patch({ includeJson: v }, false)}
        />
      </Card>

      <Card title="Custom variables">
        <div className="grid gap-3">
          {config.customVars.length === 0 ? (
            <QuietEmpty>None yet.</QuietEmpty>
          ) : (
            config.customVars.map((item) => (
              <div key={item.id} className="notice-in flex items-center gap-2">
                <Input
                  aria-label="Variable key"
                  placeholder="VAR_NAME"
                  value={item.key}
                  onChange={(e) => updateVar(item.id, "key", e.target.value)}
                />
                <Input
                  aria-label="Variable value"
                  placeholder="Value"
                  value={item.value}
                  onChange={(e) => updateVar(item.id, "value", e.target.value)}
                />
                <Button
                  variant="secondary"
                  size="icon"
                  aria-label="Remove variable"
                  onClick={() => removeVar(item.id)}
                >
                  <X className="size-4" />
                </Button>
              </div>
            ))
          )}
        </div>
        <Button variant="secondary" onClick={addVar}>
          <Plus className="size-4" />
          Add variable
        </Button>
      </Card>
    </>
  );
}

function Toggle({
  id,
  label,
  hint,
  checked,
  onChange,
}: {
  id: string;
  label: string;
  hint?: string;
  checked: boolean;
  onChange: (v: boolean) => void;
}) {
  return (
    <div className="flex min-h-11 items-center justify-between gap-4">
      <div>
        <label htmlFor={id} className="text-sm text-fg">
          {label}
        </label>
        {hint ? <p className="text-xs text-muted">{hint}</p> : null}
      </div>
      <Switch id={id} checked={checked} onCheckedChange={(v) => onChange(v === true)} />
    </div>
  );
}
