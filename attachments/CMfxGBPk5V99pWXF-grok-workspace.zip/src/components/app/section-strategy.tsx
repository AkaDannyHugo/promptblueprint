import { TIMEFRAME_MINUTES } from "@/lib/blueprint/constants";
import { useBlueprint } from "@/lib/blueprint/store";
import type {
  HoldStyle,
  LeverageVenue,
  MacroLookback,
  MarginMode,
  SignalBias,
  Timeframe,
} from "@/lib/blueprint/types";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, SelectField, SliderField } from "./field";

const TF_LABEL: Record<Timeframe, string> = {
  "15m": "15 Min",
  "1H": "1 Hour",
  "4H": "4 Hour",
  "1D": "1 Day",
  "1W": "1 Week",
};

export function StrategySection() {
  const config = useBlueprint((s) => s.config);
  const patch = useBlueprint((s) => s.patch);
  const setEntryTf = useBlueprint((s) => s.setEntryTf);
  const entryMin = TIMEFRAME_MINUTES[config.entryTf];
  const leverage = config.marketMode === "leverage";
  const biasHint =
    !leverage && config.signalBias === "short"
      ? "Spot short stays RESEARCH_ONLY unless compare finds a listed contract."
      : leverage && config.signalBias === "short"
        ? "Short is the derivative book, not the spot book."
        : leverage && config.signalBias === "both"
          ? "Each side must have a listed contract and a stop beyond entry."
          : "Drops the other direction.";

  return (
    <>
      <Card title="Market">
        <SelectField
          id="hold-style"
          label="Hold"
          value={config.holdStyle}
          onChange={(v) => patch({ holdStyle: v as HoldStyle })}
        >
          <option value="intraday">Intraday (no clock)</option>
          <option value="session">Session</option>
          <option value="swing">Swing</option>
        </SelectField>
        <div className="flex min-h-11 items-start gap-3">
          <Checkbox
            id="compare-instruments"
            className="mt-0.5"
            checked={config.compareInstruments}
            onCheckedChange={(v) => patch({ compareInstruments: v === true })}
          />
          <label htmlFor="compare-instruments" className="text-sm leading-snug text-fg">
            Compare instruments
            <span className="mt-1 block text-xs text-muted">
              One preferred row per base. The other instrument is an alternate, not a second idea.
            </span>
          </label>
        </div>
        <SliderField
          id="cluster-cap"
          label="Cluster cap"
          hint="After the score, this many names from one category. The rest are near-misses."
          value={config.clusterCap}
          display={String(config.clusterCap)}
          min={1}
          max={4}
          step={1}
          onChange={(v) => patch({ clusterCap: v })}
        />
        {leverage ? (
          <>
            <SelectField
              id="lev-venue"
              label="Venue"
              hint={
                config.leverageVenue === "global_perps"
                  ? "Non-US. Starbase names {BASE}_USDC-PERPETUAL. INTX ids are dead."
                  : "CFTC futures on Advanced Trade. Discover the product id. Do not invent it."
              }
              value={config.leverageVenue}
              onChange={(v) => patch({ leverageVenue: v as LeverageVenue })}
            >
              <option value="us_futures">US futures</option>
              <option value="global_perps">Global perps</option>
            </SelectField>
            <SelectField
              id="margin-mode"
              label="Margin"
              hint={
                config.marginMode === "cross"
                  ? "One loss can drain the other positions. Isolated is the idea default."
                  : "Isolated is the idea default."
              }
              value={config.marginMode}
              onChange={(v) => patch({ marginMode: v as MarginMode })}
            >
              <option value="isolated">Isolated</option>
              <option value="cross">Cross</option>
            </SelectField>
            <SliderField
              id="max-leverage"
              label="Max leverage"
              hint="Caps the idea. Exchange max is not this number. US crypto is about 10x. Global lists up to 50x. Neither is a default."
              value={config.maxLeverage}
              display={`${config.maxLeverage}x`}
              min={1}
              max={10}
              step={1}
              onChange={(v) => patch({ maxLeverage: v })}
            />
          </>
        ) : null}
      </Card>
      <Card title="Strategy & timeframe">
      <SelectField
        id="macro-tf"
        label="Macro context lookback"
        value={config.macroTf}
        onChange={(v) => patch({ macroTf: v as MacroLookback })}
      >
        {["24 hours", "3 days", "7 days", "30 days"].map((v) => (
          <option key={v} value={v}>
            {v}
          </option>
        ))}
      </SelectField>
      <SelectField
        id="entry-tf"
        label="Entry signal timeframe"
        value={config.entryTf}
        onChange={(v) => setEntryTf(v as Timeframe)}
      >
        {(["15m", "1H", "4H", "1D"] as Timeframe[]).map((v) => (
          <option key={v} value={v}>
            {TF_LABEL[v]}
          </option>
        ))}
      </SelectField>
      <SelectField
        id="trend-tf"
        label="Trend context timeframe"
        value={config.trendTf}
        onChange={(v) => patch({ trendTf: v as Timeframe })}
      >
        {(["1H", "4H", "1D", "1W"] as Timeframe[]).map((v) => (
          <option key={v} value={v} disabled={TIMEFRAME_MINUTES[v] < entryMin}>
            {TF_LABEL[v]}
          </option>
        ))}
      </SelectField>
      <SelectField
        id="signal-bias"
        label="Signal bias"
        hint={biasHint}
        value={config.signalBias ?? "both"}
        onChange={(v) => patch({ signalBias: v as SignalBias })}
      >
        <option value="both">Long and short</option>
        <option value="long">Long only</option>
        <option value="short">Short only</option>
      </SelectField>
      <SliderField
        id="num-ops"
        label="Number of opportunities"
        hint="Zero is allowed. Day trade prints more lines, not looser math."
        value={config.numOps}
        display={String(config.numOps)}
        min={1}
        max={10}
        step={1}
        onChange={(v) => patch({ numOps: v })}
      />
    </Card>
    </>
  );
}
