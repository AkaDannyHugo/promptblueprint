#!/usr/bin/env python3
"""Editorial share cards for Prompt Blueprint. Exact type, no generative glyphs."""

from PIL import Image, ImageDraw, ImageFont

FONTS = "/workspace/.grok/fonts"
SANS_MED = f"{FONTS}/IBMPlexSans-Medium.ttf"
SANS_SEMI = f"{FONTS}/IBMPlexSans-SemiBold.ttf"
MONO = f"{FONTS}/IBMPlexMono-Regular.ttf"

BG = (0x0B, 0x0C, 0x0E)
BONE = (0xF3, 0xF1, 0xEB)
AMBER = (0xC4, 0x7C, 0x4A)
RULE = (0xC5, 0xCE, 0xD6)  # favicon stroke, not a second accent

SCALE = 3  # supersample, then downscale for crisp IBM Plex


def mix(a, b, t):
    return tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def font(path, size):
    return ImageFont.truetype(path, size * SCALE)


def advance(text, fnt, tracking):
    if not text:
        return 0
    w = 0
    for i, ch in enumerate(text):
        w += fnt.getlength(ch)
        if i != len(text) - 1:
            w += tracking
    return w


def draw_tracked(draw, x, y, text, fnt, fill, tracking=0):
    """y is the top of the em box."""
    cursor = x
    for i, ch in enumerate(text):
        draw.text((cursor, y), ch, font=fnt, fill=fill)
        cursor += fnt.getlength(ch) + (tracking if i != len(text) - 1 else 0)
    return cursor


def metrics(fnt):
    ascent, descent = fnt.getmetrics()
    return ascent, descent, ascent + descent


def draw_sheet(draw, x, y, size):
    """Favicon document mark: bone page, cut corner, two cool rules."""
    import math

    u = (size * SCALE) / 32.0

    def p(px, py):
        return (x * SCALE + px * u, y * SCALE + py * u)

    def arc(cx, cy, r, a0, a1, n=5):
        pts = []
        for i in range(n + 1):
            t = a0 + (a1 - a0) * i / n
            pts.append(p(cx + r * math.cos(t), cy + r * math.sin(t)))
        return pts

    # SVG y-down: 0° east, 90° south.
    pts = [p(8, 5), p(20, 5), p(25, 10), p(25, 26)]
    pts += arc(23, 26, 2, 0, math.pi / 2)
    pts += [p(8, 28)]
    pts += arc(8, 26, 2, math.pi / 2, math.pi)
    pts += [p(6, 7)]
    pts += arc(8, 7, 2, math.pi, math.pi * 1.5)
    draw.polygon(pts, fill=BONE)

    stroke = RULE
    thick = max(SCALE, int(round(1.75 * u)))
    draw.line([p(11, 16.5), p(21, 16.5)], fill=stroke, width=thick)
    draw.line([p(11, 20.5), p(18, 20.5)], fill=stroke, width=thick)


def frame(draw, w, h, inset, color, width, ticks=True, tick_len=16, tick_gap=8):
    ins = inset * SCALE
    ww, hh = w * SCALE, h * SCALE
    lw = width
    draw.rectangle([ins, ins, ww - 1 - ins, hh - 1 - ins], outline=color, width=lw)
    if not ticks:
        return
    length = tick_len * SCALE
    gap = tick_gap * SCALE
    # Crop marks sit outside the frame, not touching it or the canvas edge.
    outer = ins - gap
    corners = (
        (ins, ins, 1, 1),
        (ww - 1 - ins, ins, -1, 1),
        (ins, hh - 1 - ins, 1, -1),
        (ww - 1 - ins, hh - 1 - ins, -1, -1),
    )
    tick_color = mix(BG, BONE, 0.55)
    tw = max(lw, 2)
    for cx, cy, sx, sy in corners:
        ox = cx + sx * (-gap if sx > 0 else gap) if False else cx - sx * gap
        # start just outside the corner, run away from the frame
        x0 = cx - sx * gap
        y0 = cy - sy * gap
        draw.line([(x0, y0), (x0 - sx * length, y0)], fill=tick_color, width=tw)
        draw.line([(x0, y0), (x0, y0 - sy * length)], fill=tick_color, width=tw)


def plate(draw, box, color, width):
    """Wireframe prompt sheet. Scenery only — no letters."""
    x0, y0, x1, y1 = [v * SCALE for v in box]
    draw.rectangle([x0, y0, x1, y1], outline=color, width=width)
    fold = 26 * SCALE
    # Chamfer
    draw.line([(x1 - fold, y0), (x1, y0 + fold)], fill=color, width=width)
    draw.line([(x1 - fold, y0), (x1 - fold, y0 + fold)], fill=BG, width=width + 2)
    draw.line([(x1 - fold, y0 + fold), (x1, y0 + fold)], fill=color, width=width)
    # Prompt rules inside the sheet. Lengths vary; none form glyphs.
    pad_x = 28 * SCALE
    pad_top = 46 * SCALE
    gap = 22 * SCALE
    fracs = (0.78, 0.92, 0.62, 0.84, 0.48)
    for i, frac in enumerate(fracs):
        yy = y0 + pad_top + i * gap
        if yy > y1 - 28 * SCALE:
            break
        x_end = x0 + pad_x + (x1 - x0 - 2 * pad_x) * frac
        draw.line([(x0 + pad_x, yy), (x_end, yy)], fill=color, width=width)


def render_og():
    w, h = 1200, 630
    im = Image.new("RGB", (w * SCALE, h * SCALE), BG)
    draw = ImageDraw.Draw(im)

    frame_color = mix(BG, BONE, 0.42)
    frame(draw, w, h, inset=36, color=frame_color, width=SCALE, ticks=True)

    headline = "Crypto Trading Prompts"
    wordmark = "Prompt Blueprint"
    tagline = "A paste-ready Grok contract"

    f_head = font(SANS_SEMI, 72)
    f_word = font(SANS_MED, 22)
    f_tag = font(MONO, 17)
    word_track = 0.8 * SCALE

    _, _, head_h = metrics(f_head)
    _, _, word_h = metrics(f_word)
    _, _, tag_h = metrics(f_tag)

    mark = 46
    gap_mark = 18
    gap_word = 16
    amber_h = 3
    gap_amber = 22
    gap_head = 18
    rule_h = 2
    gap_rule = 14

    block = (
        mark
        + gap_mark
        + word_h / SCALE
        + gap_word
        + amber_h
        + gap_amber
        + head_h / SCALE
        + gap_head
        + rule_h
        + gap_rule
        + tag_h / SCALE
    )
    y = (h - block) / 2

    draw_sheet(draw, (w - mark) / 2, y, mark)
    y += mark + gap_mark

    word_w = advance(wordmark, f_word, word_track)
    draw_tracked(draw, (w * SCALE - word_w) / 2, y * SCALE, wordmark, f_word, BONE, word_track)
    y += word_h / SCALE + gap_word

    amber_w = 52
    ax0 = (w - amber_w) / 2
    draw.rectangle(
        [ax0 * SCALE, y * SCALE, (ax0 + amber_w) * SCALE, (y + amber_h) * SCALE],
        fill=AMBER,
    )
    y += amber_h + gap_amber

    head_w = advance(headline, f_head, 0)
    hx = (w * SCALE - head_w) / 2
    draw_tracked(draw, hx, y * SCALE, headline, f_head, BONE, 0)
    head_box = (hx / SCALE, y, (hx + head_w) / SCALE, y + head_h / SCALE)
    y += head_h / SCALE + gap_head

    rule_color = mix(BG, BONE, 0.34)
    rx0 = head_box[0]
    rx1 = head_box[2]
    draw.rectangle(
        [rx0 * SCALE, y * SCALE, rx1 * SCALE, (y + rule_h) * SCALE],
        fill=rule_color,
    )
    y += rule_h + gap_rule

    tag_w = advance(tagline, f_tag, 0.35 * SCALE)
    draw_tracked(
        draw,
        (w * SCALE - tag_w) / 2,
        y * SCALE,
        tagline,
        f_tag,
        mix(BG, BONE, 0.62),
        0.35 * SCALE,
    )
    tag_box = ((w * SCALE - tag_w) / 2 / SCALE, y, ((w * SCALE - tag_w) / 2 + tag_w) / SCALE, y + tag_h / SCALE)

    print("OG headline box", tuple(round(v, 1) for v in head_box))
    print("OG tagline box", tuple(round(v, 1) for v in tag_box))
    print("OG block bottom", round(tag_box[3], 1), "top mark", round((h - block) / 2, 1))

    # Hard gate: title glyphs stay well inside the frame.
    assert head_box[0] > 80 and head_box[2] < w - 80, head_box
    assert head_box[1] > 80 and head_box[3] < h - 80, head_box
    assert tag_box[0] > 80 and tag_box[2] < w - 80

    out = im.resize((w, h), Image.Resampling.LANCZOS)
    out.save("/workspace/.grok/og-raw.png", "PNG")


def render_banner():
    w, h = 1200, 264
    im = Image.new("RGB", (w * SCALE, h * SCALE), BG)
    draw = ImageDraw.Draw(im)

    frame_color = mix(BG, BONE, 0.38)
    frame(draw, w, h, inset=16, color=frame_color, width=SCALE, ticks=False)

    # Vertical hairline dividing lockup from the sheet. Scenery.
    div_x = 640
    div_color = mix(BG, BONE, 0.30)
    draw.line(
        [(div_x * SCALE, 28 * SCALE), (div_x * SCALE, (h - 28) * SCALE)],
        fill=div_color,
        width=SCALE,
    )

    plate_color = mix(BG, BONE, 0.46)
    plate(draw, (700, 36, 1148, 228), plate_color, width=SCALE)

    wordmark = "Prompt Blueprint"
    headline = "Crypto Trading Prompts"
    f_word = font(SANS_MED, 18)
    f_head = font(SANS_SEMI, 40)
    word_track = 0.6 * SCALE

    _, _, word_h = metrics(f_word)
    _, _, head_h = metrics(f_head)

    x = 56
    y = 46
    draw_tracked(draw, x * SCALE, y * SCALE, wordmark, f_word, BONE, word_track)
    word_w = advance(wordmark, f_word, word_track) / SCALE
    word_box = (x, y, x + word_w, y + word_h / SCALE)
    y += word_h / SCALE + 14

    amber_w = 40
    draw.rectangle(
        [x * SCALE, y * SCALE, (x + amber_w) * SCALE, (y + 3) * SCALE],
        fill=AMBER,
    )
    y += 3 + 16

    draw_tracked(draw, x * SCALE, y * SCALE, headline, f_head, BONE, 0)
    head_w = advance(headline, f_head, 0) / SCALE
    head_box = (x, y, x + head_w, y + head_h / SCALE)

    print("BANNER word", tuple(round(v, 1) for v in word_box))
    print("BANNER head", tuple(round(v, 1) for v in head_box))

    # Safe lockup: left half, above the bottom fifth, and the block's
    # center sits above the midline.
    right_limit = w * 0.5
    bottom_limit = h * 0.8
    for name, box in (("word", word_box), ("head", head_box)):
        assert box[2] < right_limit - 24, (name, box)
        assert box[3] < bottom_limit - 16, (name, box)
        assert box[0] > 36, (name, box)
        assert box[1] > 28, (name, box)
    center_y = (word_box[1] + head_box[3]) / 2
    assert center_y < h / 2, center_y
    print("BANNER lockup center y", round(center_y, 1), "midline", h / 2)

    out = im.resize((w, h), Image.Resampling.LANCZOS)
    out.save("/workspace/.grok/x-banner-raw.png", "PNG")


if __name__ == "__main__":
    render_og()
    render_banner()
    print("raw ok")
