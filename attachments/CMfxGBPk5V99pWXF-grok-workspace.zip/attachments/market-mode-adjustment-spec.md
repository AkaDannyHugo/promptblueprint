# Adjustment spec: Prompt Blueprint as a spot / leverage idea desk

Audience: the agent that will edit this app. Do not treat this as a user-facing changelog. Implement the contract and UI changes below. Do not place orders. Do not invent market data. Do not add a charting terminal.

Product today: `Prompt Blueprint` v4.1 (`src/lib/blueprint/`). It does not scan markets itself. It builds a paste-ready contract for Grok (Coinbase tools) or a web-only model. Default profile is day trade: 15m entry, 1H trend, 60% confidence, 2R, volume universe of 50. Persistence key is `prompt-blueprint-v3`. `contractRev` is 41.

## 1. Why a daily desk cannot use it as the primary idea tool

The contract is hard-coded to one Coinbase spot screen.

- `role()` says “One Coinbase spot screen. Never trade, size, or state P(win).”
- `bounds()` says “FUTURE only if that product_id is on the watchlist. Empty watchlist cannot emit *-CDE. Spot short = RESEARCH_ONLY.”
- `derivatives()` reads OKX then Hyperliquid funding as a score pillar. Coinbase is explicitly “no funding.” A dated FUTURE is not funding.
- Entry is spot book: long = best ask, short = best bid.
- Universe mode `perp_oi` still ranks Coinbase spot by volume and defers OI (`UNIVERSE_MODES` hint in `constants.ts`).
- Output columns are Rank, Ticker, Signal, Score, Entry, Stop, Target, R:R, Path, Held. No instrument, leverage, liquidation, funding carry, basis, session, or time stop.
- Header subtitle is “Day desk · screen only”. There is no market control.

That is correct for a spot screen and wrong for leverage. A short on spot is not a short. A 2R target that ignores funding and liquidation is not a 2R trade. Switching “signal bias” to short does not switch the instrument.

## 2. Facts the contract must encode (do not guess product ids)

Verified against Coinbase docs and help as of 2026-10-04.

Coinbase Advanced Trade has three markets, not one:

1. Spot. `BASE-USD` / `BASE-USDC`. Stays on the Advanced Trade API.
2. US futures. CFTC-regulated, eligible US clients, Coinbase Financial Markets / Coinbase Derivatives (CDE). Stays on the Advanced Trade API. Includes nano crypto futures and perp-style futures (example: nano Bitcoin perp-style, symbol BIP, 0.01 BTC, cash-settled USD, listed on CDE). Crypto leverage is about 10x; commodity futures up to about 25x intraday. Intraday margin window is 18:00 ET to 16:00 ET next day, Sunday evening through Friday afternoon. Positions held past 16:00 ET, and all weekend holds, take the higher overnight margin. Day-trade margin is not available on weekends or holidays.
3. Global derivatives. Eligible non-US clients. On 2026-10-01 these moved off INTX onto a Deribit-powered Starbase gateway. INTX perpetuals are no longer on the Advanced Trade API. Spot and US futures were not moved. Global set is 125+ perpetuals, up to 50x, including some equity and commodity perps. Options and dated futures are not on that gateway yet. Instrument names changed: `BTC-PERP-INTX` is retired; the new form is `{BASE}_USDC-PERPETUAL` (example `BTC_USDC-PERPETUAL`), confirmed via `public/get_instruments`. Margin is chosen per portfolio: cross or segregated (isolated), and portfolio or standard.

Other desk rules, used as defaults not as claimed edge:

- Professional pre-trade checks separate instrument choice from direction. Spot has no liquidation. Perps add funding, mark-vs-last, and a liquidation price. A practical gate is liquidation at least 2x the stop distance beyond entry (if the stop is 5% away, liquidation should be at least 10% away). If that fails, cut leverage. Do not raise risk.
- Risk is a fraction of equity, not a leverage setting. 0.75% per idea is already the app’s guidance. Keep it. Leverage only changes notional and margin.
- Funding is an 8h-normalized rate only when the venue interval is known. The app already forbids comparing an hourly print to `0.0005`. Keep that.
- One OI print is a level, not a change. Keep that.
- Extreme positive funding with flat or falling price is a crowded-long tag, not an entry. Basis (perp or future mark versus spot) above about 0.3% with positive funding is the same tag. A perp discount in an uptrend is a continuation tag, not an auto long.
- Do not double-count correlated alts. Cap independent ideas per cluster.
- Session VWAP is the intraday bias anchor for day-trade longs. Mean-reversion may fade it. Other profiles must not require it.
- Exchange max leverage is not a desk default. 50x global and 10x US are ceilings to warn against, not presets.

## 3. Product decision

Add a first-class market mode. Switching it rewrites the contract immediately. It must not reset profile, weights, watchlist, denylist, or timeframes.

Modes:

- `spot` — current behavior, preserved byte-for-byte in meaning.
- `leverage` — listed derivative only. Shorts are real. Missing contract means no leverage row.

Leverage venue, required when mode is leverage:

- `us_futures` — Advanced Trade futures. Discover with the Coinbase tool. Never invent `*-CDE`, `BIP`, or a dated code.
- `global_perps` — Starbase gateway, `{BASE}_USDC-PERPETUAL` only after the instrument list confirms it. Never emit `*-PERP-INTX`.

Default for existing users: `spot`. Default venue if they flip to leverage: `us_futures`. A header control makes the flip one click. A compare toggle emits one preferred instrument per base, not two full screens.

Do not add order entry, `orders_create`, position sync, or a live chart. `orders_preview` stays optional and read-only. The app remains a contract builder.

## 4. Files to change

- `src/lib/blueprint/types.ts` — new fields.
- `src/lib/blueprint/constants.ts` — version 4.2, rev 42, mode copy, profile patches.
- `src/lib/blueprint/prompt.ts` — branch role, bounds, surface, procedure, derivatives, setups, output.
- `src/lib/blueprint/llm.ts` — tool block per mode. Do not invent tool names.
- `src/lib/blueprint/warnings.ts` — mode conflicts.
- `src/lib/blueprint/store.ts` — hydrate defaults. Keep persist name `prompt-blueprint-v3`.
- `src/lib/blueprint/format.ts` — snapshot label includes mode.
- `src/components/app/header.tsx` — Spot | Leverage control and subtitle.
- `src/components/app/section-strategy.tsx` — venue, margin, hold, compare.
- `src/components/app/section-risk.tsx` — leverage, liquidation buffer, funding drag, overnight.
- `src/components/app/section-universe.tsx` — base-ticker hint; perp universe hint.
- `src/components/app/section-output.tsx` — no new model logic except the compare toggle lives in strategy.
- `src/components/app/prompt-pane.tsx` — mode badge.
- `src/components/app/guide-dialog.tsx` — one paragraph on the switch.
- `src/components/app/config-panel.tsx` — no new tab. Mode is header-level so it is visible on every tab.

No new route. No auth. No database. Local persist only.

## 5. Schema

Add to `BlueprintConfig`:

```ts
export type MarketMode = "spot" | "leverage";
export type LeverageVenue = "us_futures" | "global_perps";
export type MarginMode = "isolated" | "cross";
export type HoldStyle = "intraday" | "session" | "swing";

marketMode: MarketMode;          // default "spot"
leverageVenue: LeverageVenue;    // default "us_futures"
marginMode: MarginMode;          // default "isolated"
maxLeverage: number;             // default 3, slider 1–10 step 1
liqBufferMultiple: number;       // default 2, slider 1.5–3 step 0.5
fundingDragR: number;            // default 0.25, slider 0.1–0.5 step 0.05
holdStyle: HoldStyle;            // default from profile
compareInstruments: boolean;     // default false
clusterCap: number;              // default 2, slider 1–4
```

`holdStyle` mapping when a profile is applied:

- dayTrade → `intraday` (flat before 16:00 America/New_York)
- momentum → `session` (about 4–8 hours, may cross 16:00)
- meanReversion, balanced, conservative → `swing`

Switching market mode must not change `holdStyle`. Applying a profile may.

`hydrateConfig` fills any missing field from `DEFAULT_CONFIG`. Bump `contractRev` to 42. Do not migrate a saved spot config into leverage. Snapshots keep the mode they were saved with.

`snapshotName`: prefix `Spot` or `Lev`. Example: `Lev · Day trade · Top 50 volume · 15m/1H`.

## 6. Header switch

In `header.tsx`, next to the wordmark, a two-segment control:

- Spot
- Leverage

`aria-pressed` on the active side. Click calls `patch({ marketMode }, false)` so it does not mark the profile custom. Subtitle:

- spot: `Day desk · spot screen`
- leverage + us_futures: `Day desk · US futures`
- leverage + global_perps: `Day desk · global perps`

Mobile: the control stays on the first header row, not inside the scrolling profile chips. Minimum height 44px. Do not use a select.

Prompt pane badge, left of the version string: `SPOT` or `LEV · US` or `LEV · GLOBAL`. Amber if leverage and `maxLeverage` > 5.

## 7. Strategy section additions

Card “Market”, above timeframes, only the fields the mode needs.

Always:

- Hold: Intraday (flat by 16:00 ET) / Session / Swing.
- Compare instruments toggle. Hint: “One preferred row per base. The other instrument is an alternate, not a second idea.”

Only if `marketMode === "leverage"`:

- Venue: US futures / Global perps. Hint under US: “CFTC futures on Advanced Trade. Discover the product id. Do not invent it.” Hint under Global: “Non-US. Starbase names `{BASE}_USDC-PERPETUAL`. INTX ids are dead.”
- Margin: Isolated (default) / Cross. Cross hint: “One loss can drain the other positions. Isolated is the idea default.”
- Max leverage slider, 1–10, display `3x`. Hint: “Caps the idea. Exchange max is not this number. US crypto is about 10x. Global lists up to 50x. Neither is a default.”

Signal bias copy changes with mode:

- spot + short: hint “Spot short stays RESEARCH_ONLY unless compare finds a listed contract.”
- leverage + short: hint “Short is the derivative book, not the spot book.”
- leverage + both: hint “Each side must have a listed contract and a stop beyond entry.”

## 8. Risk section additions

Show only in leverage mode, card “Leverage gates”:

- Liquidation buffer, default 2x stop distance. Hint: “Liquidation must sit at least this many times the stop distance beyond entry. Else cut leverage. Do not widen the stop.”
- Funding-drag reject, default 0.25R. Hint: “If the planned hold pays more than this in funding, drop. Dated futures use basis, not funding.”
- Overnight note, not a slider: if `holdStyle` is session or swing, show an info notice “Hold can cross 16:00 ET. US futures use overnight margin, not the intraday rate.”

Spot mode hides these sliders. Do not leave a dead 3x control on a spot contract.

## 9. Contract text

Keep the block order: role, bounds, custom data, surface, tools, steps, derivatives, score, setups, out.

### 9.1 Role

Spot, unchanged meaning:

`You are an Expert Macro Crypto Trader. One Coinbase spot screen. Never trade, size, or state P(win).`

Leverage:

`You are an Expert Macro Crypto Trader. One Coinbase leverage screen on {US futures|global perps}. Never trade, size an order, or state P(win). Leverage changes notional, not risk. Shorts are the listed contract, not a spot sale.`

Both still include profile, bias, entry, trend, macro-is-context.

### 9.2 Bounds

Spot: keep the current FUTURE / `*-CDE` / RESEARCH_ONLY lines.

Leverage, US futures:

```
Instrument is a listed Advanced Trade future. Discover it. Never invent BIP, *-CDE, or a dated code.
INTX ids are retired. Do not emit them.
No listed contract → no leverage row. Tag NO_LISTED_CONTRACT.
Spot short is not a fill on this screen.
One product per base. Prefer the perp-style future if both a perp-style and a dated future exist, unless the dated basis is the setup.
```

Leverage, global perps:

```
Instrument is {BASE}_USDC-PERPETUAL only if get_instruments (or the listed tool) returns it.
BTC-PERP-INTX and any *-PERP-INTX are retired as of 2026-10-01. Never emit them.
No listed contract → no leverage row. Tag NO_LISTED_CONTRACT.
```

Both leverage venues:

```
Do not use exchange max leverage. Cap at {maxLeverage}x.
Isolated margin unless the config says cross.
Risk stays {0.75}% of capital guidance. Notional = risk / stop distance. Margin = notional / leverage used.
Never orders_create.
```

### 9.3 Surface

Spot: keep connector / web / bot.

Leverage adds: a fillable price is the derivative book or mark from the same venue, not the spot mid. Spot mid is allowed only as the basis denominator. If the derivative book is missing, the row is not fillable. Do not substitute an OKX price as the entry.

### 9.4 Tools

Grok block, spot: keep the current Coinbase discovery text.

Grok block, leverage, append:

```
Also discover futures or perpetual products, positions, and margin if those tools are returned. Call exact names only.
US futures stay on Advanced Trade. Global perps are the Starbase gateway, not INTX.
If the tool list has no derivative product call, say so and do not invent ids.
```

Web models: they may read a public derivatives page for funding, OI, and basis. That page is web, not a fill. Entry still requires a cited book or mark.

### 9.5 Steps

Shared, both modes:

- Pass A/B/C structure stays.
- Add RS: 24h excess return versus BTC. `>+1%` tag `RS_LEADER`. `<-1%` tag `RS_LAGGARD`. Missing BTC print → `na`, not 0.
- Cluster cap: after score, keep at most `clusterCap` names from the same category (L1, L2, meme, AI, DeFi, other). Overflow is near-miss `CORR_CLUSTER`.
- Day-trade profile only: long above session VWAP, short below, unless profile is mean reversion. Missing VWAP → tag `VWAP_NA`, do not drop.
- Time stop in the row: intraday = 16:00 America/New_York; session = 8h; swing = 5 daily closes.

Leverage Pass A:

- Rank the configured universe, then map each survivor to a listed contract before Pass B.
- Unmapped names do not enter Pass B on a leverage screen.
- `perp_oi` mode: rank by listed OI after the map, not by spot volume. If OI is missing, fall back to spot volume and tag `OI_RANK_DEFERRED`.

Leverage Pass B:

- Book and candles are the derivative product if the tool returns them. Else spot candles for structure only, and entry is the derivative mark. Say which.
- ATR math is unchanged (Wilder 14, drop the forming bar).
- Basis = (mark - spot mid) / spot mid. Print it. `na` if either side is missing.
- Funding: venue print, normalized to 8h only if interval is 1, 2, 4, or 8. Dated future funding is `na`. Do not copy the OKX path onto a Coinbase future that has its own print.

Leverage math block, required in SETUPS:

```
Stop distance = |entry - stop| / entry.
Used leverage = min(config max, the leverage that puts liquidation at least {liqBufferMultiple}x stop distance beyond entry).
Long isolated sketch: liq = entry * (1 - 1/lev + maint). Short mirrors.
Maint unknown → 0.005 and tag MAINT_ASSUMED.
If even 1x fails the buffer, drop LEV_LIQ_BUFFER. Do not widen the stop to pass.
US futures and holdStyle session or swing → tag OVERNIGHT_MARGIN. Intraday hold that ends before 16:00 ET on a weekday may use the day rate. Weekend hold is overnight.
Funding cost over the planned hold = rate_8h * (hold_hours / 8) * notional, signed.
Paying more than {fundingDragR}R → drop FUNDING_DRAG.
Dated future: funding na. If |basis| > 0.3% against the trade and expiry is inside the hold, drop BASIS_DRAG.
Net R = gross R minus fees and funding, in R units. Rank on net R, then score.
```

Do not present the liquidation sketch as the exchange’s official engine. The contract must say “sketch, tag MAINT_ASSUMED, cut leverage if the buffer fails.”

### 9.6 Derivatives pillar

Spot: keep the OKX then Hyperliquid block. It is context, not the traded instrument.

Leverage: the traded venue’s funding and OI come first. OKX or Hyperliquid is a disagreement check only. If the traded venue has a number, do not replace it. Disagreement (sign flip versus the context venue) tags `FUNDING_DISAGREE` and applies the existing 0.90 funding penalty. It does not average the two rates.

OI change still requires two timestamps or a 24h-change field. One print adds no direction.

Crowding tags, not entries:

- funding_8h ≥ 0.0005 and price flat or down over the macro window → `CROWDED_LONG`
- funding_8h ≤ -0.0005 and price flat or up → `CROWDED_SHORT`
- basis ≥ 0.003 and funding positive → `PREMIUM`
- basis ≤ -0.003 and trend up → `DISCOUNT_CONTINUATION`

### 9.7 Score

Keep na-dropping, coverage on tech+rr, sentiment cannot clear the gate, RRR bands, penalty floor.

Leverage additions to the penalty product, still floored at `penaltyCap`:

- `FUNDING_DISAGREE` × 0.90 (already the funding-against factor; do not stack a second 0.90 on the same input)
- `OVERNIGHT_MARGIN` is a tag, not a penalty
- Rank key is net R then final score. Say that in SCORE so the model does not sort on gross R.

Spot rank key stays final, SURGE, depth, volume.

### 9.8 Setups

Spot entry rule stays: long = best ask, short = best bid, spot short = RESEARCH_ONLY.

Leverage entry rule:

```
Long entry = derivative best ask, or mark if the book is missing (tag MARK_ENTRY).
Short entry = derivative best bid, or mark.
Stop is beyond entry on the derivative price, else that side is invalid.
Target is the nearer of the opposite swing and 2R, then reduced by estimated fees and funding. If net R < min RRR, drop.
Invalidation is the structure break. It may equal the stop. Print both.
```

### 9.9 Output

Spot table: keep the current columns.

Leverage table:

```
Rank | Ticker | Instrument | Side | Lev | Score | Entry | Stop | Liq | Target | Net R | Funding 8h | Basis | Path | Held
```

Rationale line adds: Margin isolated|cross; Hold; Time stop; RS; Cluster; Tags.

Compare mode, either market, extra block after the table, max 5 bases:

```
COMPARE
BASE | Spot idea | Listed contract | Preferred | Why
```

Preferred is the listed contract when the side is short, or when net R after funding beats spot by 0.2R or more. Otherwise spot. A missing contract does not invent a preferred leverage row. Compare does not increase `numOps`. Alternates are not extra ranked ideas.

JSON, if enabled, add optional fields rather than a second schema: `market_mode`, `instrument`, `leverage`, `liq`, `net_rrr`, `funding_8h`, `basis`, `time_stop`. Omit any field not sourced this session.

## 10. Warnings

Add, do not remove existing notices:

- leverage + signalBias short + compare off: info “Shorts need a listed contract. Unmapped names drop.”
- leverage + global_perps: info “Global perps are non-US. INTX ids are retired.”
- leverage + maxLeverage > 5: warn “Above 5x is a leverage cap, not an edge. Liquidation buffer still cuts it.”
- leverage + marginMode cross: warn “Cross margin lets one idea drain the book.”
- leverage + holdStyle intraday + trendTf 1D or 1W: warn “Intraday hold with a daily trend is a mismatch.”
- spot + compare on: info “Compare will look for a listed contract and still keep spot shorts as research.”
- category Stablecoin + leverage: warn “Stable leverage contracts are usually missing. Expect an empty list.”

## 11. Profile patches

Do not change spot numbers. On leverage, `applyProfile` also sets:

| Profile | maxLeverage | liqBuffer | fundingDragR | holdStyle | minRrr |
| --- | --- | --- | --- | --- | --- |
| dayTrade | 3 | 2 | 0.25 | intraday | 2 |
| momentum | 3 | 2 | 0.25 | session | 2 |
| meanReversion | 2 | 2 | 0.2 | swing | 1.5 |
| balanced | 2 | 2 | 0.2 | swing | 1.5 |
| conservative | 2 | 2.5 | 0.15 | swing | 2 |

Weights stay on the existing pillars. Do not add a seventh pillar. Leverage quality is a gate and a rank key, not a new score weight. A new weight would break the sum-to-100 rule and every saved snapshot.

## 12. Universe copy

Watchlist placeholder stays `ETH-USD, SOL-USD`. Hint becomes “Bases. Spot uses the USD product. Leverage maps the base to a listed contract.”

`perp_oi` hint:

- spot: keep the current “Pass A still ranks Coinbase spot” sentence.
- leverage: “Pass A maps to listed contracts, then ranks by open interest. Missing OI falls back to spot volume and is tagged.”

Denylist matches base or full product id. `ETH-USD` denies `ETH` on both modes.

## 13. Guide copy

Replace the first paragraph with two short paragraphs:

- Spot default is unchanged: 15m / 1H, 60% floor, tags instead of deletes, paste into Grok with Coinbase connected, no orders.
- Leverage is the header switch. It asks for a listed US future or a global `{BASE}_USDC-PERPETUAL`, caps leverage, and drops a name whose liquidation sits inside the stop buffer or whose funding drag eats the R. Shorts are real only on that contract. INTX ids are not used.

## 14. What not to build

- No `orders_create`, no size button that submits, no “trade this” link that implies execution.
- No fake probability of winning.
- No hardcoded product ids. BIP may appear in help text as an example of a CDE nano, never as a default emit.
- No INTX names anywhere in generated text except the sentence that forbids them.
- No liquidation heatmap widget, no embedded TradingView, no Coinglass scrape. The contract may cite a public page the model opens. The app does not fetch it.
- No seventh scoring pillar and no weight migration that rewrites user snapshots.
- Do not change the persist key. A new key would orphan saved desks.

## 15. Acceptance checks

1. Fresh load is spot, day trade, contract still says spot short = RESEARCH_ONLY and does not emit a leverage table.
2. Header Leverage flips the contract without clearing the watchlist. Subtitle and badge update. Profile stays day trade.
3. Flip back to Spot restores the spot role and table. Leverage sliders hide. Their values remain in state.
4. US futures contract contains “Never invent”, the 16:00 ET overnight rule, the 2x liquidation buffer, and no `BTC-PERP-INTX`.
5. Global venue contract uses `{BASE}_USDC-PERPETUAL` and says INTX is retired.
6. `maxLeverage` 8 shows the warning. The contract cap equals 8, not 50.
7. Compare on adds a COMPARE block and does not raise the opportunity count.
8. Import of a rev-41 config stays spot and gains the new defaults. A snapshot saved in leverage reloads as leverage.
9. Weights still sum and normalize as today. Reset still returns the day-trade spot default.
10. Mobile 390px: the Spot | Leverage control is visible without horizontal scroll. Contract pane still scrolls.

## 16. Order of work

1. Types, defaults, hydrate, rev 42.
2. Header control and badge, so the switch exists before the prompt branches.
3. Prompt branches for role, bounds, steps, setups, output. Spot path must stay equivalent.
4. Leverage risk and strategy controls, warnings, guide, snapshot label.
5. Compare block last.

Do not refactor unrelated prompt sentences. The spot contract is already strict about na versus 0, Wilder ATR, and tool names. Leave that machinery alone.
