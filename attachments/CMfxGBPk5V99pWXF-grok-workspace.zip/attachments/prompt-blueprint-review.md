# Prompt Blueprint review — changes for the implementing model

Audience: the model that will edit this app. Do not treat this as a new trading prompt. Edit the generator so the next pasted contract does not repeat the failures below.

App: `src/lib/blueprint/prompt.ts` builds the contract. Profiles live in `src/lib/blueprint/constants.ts`. Notices live in `src/lib/blueprint/warnings.ts`. Copy shown to the user lives in `src/components/app/guide-dialog.tsx` and `src/components/app/section-scoring.tsx`.

Evidence: a Grok connector run of the generated day-trade spot contract on 2026-10-08 03:32–03:43 UTC. Coinbase tools returned numbers. Qualified was 0. That empty list was valid under the written rules, and it was also forced by rules that cancel each other.

## What the live run proved

- Pass A and the dollar gate worked. 27 names cleared quote notional ≥ $5,000,000 after dropping stables and wrapped.
- Wilder ATR on closed 15m bars worked when computed from connector candles. BTC, ETH, XRP, SOL, HYPE were correctly `ATR_BELOW_FLOOR` (0.23–0.35% vs a 0.40% floor).
- The setup rule made the profile side fail RRR. Stop = last 6 closed 15m extremes. Target = nearer of the opposite swing and 2R. On a 15m book the 6-bar extreme is wide, so the side the day-trade profile wants (short below VWAP in a 1H downtrend) prints RRR 0.3–1.5 and is dropped. The other side prints RRR 2.0 only because the target is forced to 2R. That side then takes `HTF disagrees ×0.85` and cannot clear 60.
- Tech points were invented. The contract sets tech = 35 and never says how to award points inside that 35.
- Regime points are absolute (`Aligned 16–20`) while the day-trade weight is 5. Those numbers cannot be awarded.
- The RR band string is malformed when min RRR is 2.0. The generator emits `[2.0,2) 0.53*rr; [2,2.5) 0.73*rr`.
- Funding first-match treats `|f|<0.0001` before the against branch, so a small adverse rate is scored as flat.
- RVOL, VWAP, RSI, and mcap were left na because the contract names them and does not say which field is the input.
- Sentiment is specified as one sample and n<5. Per-ticker n never reached 5 except ZEC, and only after a second search.
- VIX 15.08 was the official Cboe close at 16:15 ET. The web >45m rule marked regime na on an evening scan. Cash VIX cannot be fresher than that after the close.
- The scan ran at 23:42 ET, after the 16:00 ET time stop. The contract still asked for fillable entries.

Do not "fix" this by lowering the confidence floor. The empty table was the contract working as written. Change the contract.

## Change 1 — stop the setup rule from manufacturing a countertrend 2R

File: `src/lib/blueprint/prompt.ts`, function `setups`, spot branch around the line that emits `Long entry = best ask...`.

Current:

```text
Long entry = best ask, short = best bid. Stop = extreme of the last 6 closed ${entryTf} bars ± one tick, and it must be beyond entry, else that side is invalid. Target = nearer of the opposite swing and 2R, beyond entry.
```

Replace with:

```text
Profile side first. Day trade: long only if last close is above session VWAP; short only if last close is below session VWAP. Other profiles: long only if entry-tf structure agrees with the trend timeframe; short only if it agrees. Do not score the other side to manufacture RRR. A failed profile side is near-miss PROFILE_SIDE, not a flip.
Entry: long = best ask, short = best bid, from the last connector book. Stop = extreme of the last 6 closed entry-tf bars ± one tick, beyond entry, else that side is invalid.
Target = the nearer of (opposite swing beyond entry) and (entry ± minRrr × risk). If the nearer target gives RRR < minRrr, drop RRR. Do not replace it with a 2R target on the other side.
If now is after the time stop in America/New_York, tag SESSION_CLOSED and emit no fillable row. Research rows are allowed and must say SESSION_CLOSED.
```

Why: on the live book, NEAR short was the profile side and failed RRR once price drifted; NEAR long, ZEC long, ADA long, UNI long, and PUMP long printed RRR 2.0 only as the forced countertrend. Those rows then died on the HTF penalty. The app currently advertises "more asymmetric setups" and the generator prevents them.

Also change `section-scoring.tsx` hint on Minimum R/R from "Keeps the extra names asymmetric" to "Profile side must clear this R. The contract must not flip side to print it."

## Change 2 — fix the RR band generator

File: `src/lib/blueprint/prompt.ts`, function `score`, the line that starts `RR points only after the floor`.

Current pattern:

```text
[${minRrr},2) 0.53*rr; [2,2.5) 0.73*rr; [2.5,3) 0.87*rr; ≥3 full
```

When `minRrr` is 2.0 this is an empty first interval plus a duplicate 2.0 boundary. Build the bands from `minRrr`, not from the constants 2 and 2.5.

Replacement logic:

```ts
const floor = config.minRrr;
const b1 = floor + 0.5;
const b2 = floor + 1;
`RR points only after the floor, else 0 and reject RRR: [${floor.toFixed(1)},${b1.toFixed(1)}) 0.73*rr; [${b1.toFixed(1)},${b2.toFixed(1)}) 0.87*rr; ≥${b2.toFixed(1)} full.`
```

Why: the executor had to guess whether RRR 2.0 was 0.53 or 0.73 of the pillar. A score contract cannot contain an empty interval.

## Change 3 — regime points must be fractions of the configured weight

File: `src/lib/blueprint/prompt.ts`, function `score`, the regime sentence.

Current:

```text
Regime na without a cited VIX, DXY, yield, or BTC.D. Aligned 16–20. Opposed 0–6. Sideways and not opposed → na.
```

Replace:

```text
Regime na unless this session cites one VIX, DXY, 10y yield, or BTC.D with a timestamp. Official cash close counts after that market is closed; do not mark it stale solely because the cash session ended. Crypto-native prints older than the web staleness window are na.
Aligned = 0.80*regime to 1.00*regime. Opposed = 0 to 0.30*regime. Sideways and not opposed → na, not 0.
```

Why: day-trade regime weight is 5. "Aligned 16–20" is unreachable and invites the model to ignore the weight table. Evening scans were marking a valid VIX close na.

## Change 4 — add a tech rubric so points are not invented

File: `src/lib/blueprint/prompt.ts`, function `score`, immediately after the weight line.

Insert:

```text
Tech points, sum to the tech weight, 0 if that input is na:
- 0.30 trend agreement with the trend timeframe
- 0.25 entry-tf structure (break, continuation, or reclaim — one, not all)
- 0.20 RSI location (wilder 14 on closed entry bars; >70 long or <30 short scores 0 on a momentum profile)
- 0.15 session VWAP side
- 0.10 RS tag
Do not award the trend bucket if HTF disagrees. The ×0.85 penalty still applies.
RSI formula: seed = mean gain and mean loss of the first 14 close-to-close changes, then Wilder smooth. <14 changes → RSI na and the tech cap applies.
```

Why: the live score used 6/21, 14/35, and 16/35 with no shared scale. Two runs of the same book cannot be compared. The cap rule stays; this only fills the bucket.

## Change 5 — specify RVOL and VWAP inputs

File: `src/lib/blueprint/prompt.ts`, function `procedure`, the RVOL sentence and the day-trade VWAP sentence.

RVOL replacement:

```text
RVOL numerator = connector volume_24h × connector price. volume_24h is base size. Denominator = mean of the prior 20 closed daily quote notionals (daily base volume × daily close). Exclude the forming daily candle from the denominator. <20 closed days → na. Do not use the partial daily candle as the numerator.
```

VWAP replacement, in the day-trade profile sentence:

```text
Session VWAP = sum(typical × volume) / sum(volume) on closed entry-tf candles since 09:30 America/New_York. typical = (high+low+close)/3. Drop the forming candle. No volume on those candles → VWAP_NA, do not drop. Do not approximate VWAP from 1h closes if entry candles have volume.
```

Why: the first run left both na. The second run used a partial UTC day and 1h closes. Those are different indicators. The generator must name the field.

## Change 6 — funding first-match order

File: `src/lib/blueprint/prompt.ts`, function `derivatives`, the sentence that starts `Let cap = deriv cap from SCORE. First match`.

Replace the first-match list with this order:

```text
First match, stop at the first hit: both funding and OI-change na → pillar na. Agrees (long and rate≤0, or short and rate≥0) and |f|≥0.0001 → ≤cap. Agrees and |f|<0.0001 → 0.4*cap. Against and |f|≥0.0005 → 0.2*cap and ×0.90. Against and |f|<0.0005 → 0.5*cap. OI level adds no direction.
```

Apply the same order in the leverage branch.

Why: UNI and ADA had a small positive funding on a long. The old order hit `|f|<0.0001 → 0.4*cap` before the against branch. The against case was never scored.

## Change 7 — sentiment is per ticker, with a query

File: `src/lib/blueprint/prompt.ts`, function `procedure` step 4, and function `score` sentiment sentence.

Replace `Then one DERIV path and one sentiment sample.` with:

```text
Then one DERIV path for each Pass C name, and one post search per Pass C ticker. Query: ($TICKER) within_time:12h. n is unique author+text for that ticker, not the batch. Articles are not posts. n below the configured minimum → na for that ticker only.
```

Why: one mixed sample cannot fill a 20-point pillar, and a ZEC post was being counted toward ADA. `sentimentMinN` in the UI is then actually enforceable.

## Change 8 — mcap and on-chain need a source or they are not gates

File: `src/lib/blueprint/prompt.ts`, function `procedure`, cheap-gates sentence.

Add:

```text
Mcap: one CoinGecko markets request for the Pass B bases. No number → MCAP_NA, keep the name, and do not claim the mcap gate fired. On-chain: one DefiLlama TVL number or na. A post mentioning usage is not on-chain. TVL-only uses the on-chain cap. No other on-chain source.
```

File: `src/lib/blueprint/constants.ts`, `PROFILE_PATCHES.dayTrade.weights`.

Set `onchain: 0` and add those 5 points to `technical` (40). Day trade has no on-chain path today, so the weight is decorative.

Why: the live contract said mcap ≥ $10,000,000 and then kept every name as MCAP_NA. The gate never ran. On-chain was na for every name.

## Change 9 — require a calc step, forbid prose ATR

File: `src/lib/blueprint/prompt.ts`, function `procedure`, after the ATR definition.

Insert:

```text
Compute ATR, RSI, VWAP, and RVOL in code from the closed bars. Do not compute them in prose. If code cannot be run, those fields are na. Drop the forming candle before the calc. Refresh best_bid_ask after the calc, and use that print for entry.
```

File: `src/lib/blueprint/llm.ts`, grok block.

Add after the candle sentence:

```text
Pass B candles: entry timeframe limit ≥ 40, trend timeframe limit ≥ 30, 1d limit ≥ 22. No per-name ticker. Book limit 50 only for Pass B names.
If products_list returns no cursor, that page is the universe. Do not invent a next page.
```

Why: the first ATR was hand-summed from 18 true ranges. It happened to be directionally right, and it is not a repeatable method. The 141-product page had no cursor; the contract only says "paginate".

## Change 10 — notices the UI should show

File: `src/lib/blueprint/warnings.ts`, function `getNotices`.

Add these notices:

- If `holdStyle === "intraday"` and `entryTf === "15m"` and `minRrr >= 2` and `slValidationMaxAtr` is set: info, "6-bar stop plus nearer-swing target will reject most 15m profile sides. The contract no longer flips side to print 2R."
- If `weights.regime < 16` : info, "Regime points are fractions of this weight, not a 16–20 scale."
- If `weights.onchain > 0` and market mode is spot: info, "On-chain stays na unless DefiLlama returns a number."
- If `signalBias === "short"` and market mode is spot: warn already exists in spirit; keep "Spot short stays RESEARCH_ONLY."

File: `src/components/app/guide-dialog.tsx`.

Replace the sentence "Lower than a swing screen so more asymmetric setups print" does not exist there, but the scoring hint does. In the guide, add one sentence: "An empty table is a valid scan. A 15m profile side that cannot clear the R floor is a near-miss, not a reason to take the other side."

## Change 11 — category map

File: `src/lib/blueprint/prompt.ts`, cluster sentence in `procedure`.

Replace the parenthetical category list with:

```text
Category map, else other: BTC,ETH,SOL,ADA,NEAR,SUI,AVAX,ATOM,DOT,APT,SEI,TIA = L1; ARB,OP,MATIC,POL,STRK,BASE = L2; DOGE,SHIB,PEPE,BONK,WIF,PUMP,PENGU,FLOKI = meme; TAO,FET,RENDER,WLD,NMR = AI; UNI,AAVE,MKR,LDO,CRV,AERO,ONDO = DeFi. Unknown → other. Cap applies after score.
```

Why: the live run guessed ZEC as L1 and QNT as other. Cluster overflow cannot be audited without a map.

## Do not change

- `na` is not 0. That rule saved the run from invented prices.
- Spot short = RESEARCH_ONLY. Keep it.
- Never `orders_create`. Keep it.
- ATR floor cannot be saved by depth. The live BTC/ETH/XRP drops were correct.
- Empty qualified list is not a halt. Keep it.
- Do not raise `numOps` or lower `confidence` to force rows.

## Acceptance check

Regenerate the day-trade spot prompt and confirm the pasted text contains all of these strings:

- `Profile side first`
- `Do not score the other side`
- `SESSION_CLOSED`
- `0.80*regime`
- `volume_24h × connector price`
- `09:30 America/New_York`
- `First match, stop at the first hit`
- `per Pass C ticker`
- `Compute ATR, RSI, VWAP, and RVOL in code`
- no occurrence of `[2.0,2)`

A second connector run should be able to reject NEAR short as RRR without emitting NEAR long as a qualified row.
